// src/routes/assessments.js
const express = require('express');
const { PrismaClient } = require('@prisma/client');
const { authenticate, isAdmin, isReviewer, ownsAssessment } = require('../middleware/auth');
const { calculateScores } = require('../controllers/scoreCalculator');

const router = express.Router();
const prisma = new PrismaClient();

// ─── LIST ────────────────────────────────────────────────

// GET /api/assessments — Assessmentlər siyahısı
router.get('/', authenticate, async (req, res, next) => {
  try {
    const { status, year, organizationId } = req.query;

    const where = {};
    if (status)         where.status = status;
    if (year)           where.year = parseInt(year);
    if (organizationId) where.organizationId = organizationId;

    // Qurum yalnız öz assessmentlərini görür
    if (req.user.role === 'QURUM') {
      where.organizationId = req.user.organizationId;
    }

    const assessments = await prisma.assessment.findMany({
      where,
      include: {
        organization: { select: { id: true, name: true, shortName: true, group: true } },
        createdBy:    { select: { id: true, fullName: true } },
        reviewedBy:   { select: { id: true, fullName: true } },
        scores:       { include: { criterion: { select: { code: true, name: true, weight: true } } } }
      },
      orderBy: { updatedAt: 'desc' }
    });

    // Hər assessment üçün ümumi çəkili balı hesabla
    const result = assessments.map(a => ({
      ...a,
      totalScore: computeWeightedScore(a.scores)
    }));

    res.json(result);
  } catch (err) { next(err); }
});

// GET /api/assessments/:id — Tək assessment
router.get('/:id', authenticate, ownsAssessment, async (req, res, next) => {
  try {
    const assessment = await prisma.assessment.findUnique({
      where: { id: req.params.id },
      include: {
        organization: true,
        createdBy:    { select: { id: true, fullName: true, role: true } },
        reviewedBy:   { select: { id: true, fullName: true } },
        answers: {
          include: {
            question: { include: { criterion: true, options: true } },
            option: true
          }
        },
        scores: {
          include: {
            criterion: { select: { id: true, code: true, name: true, nameAz: true, weight: true, orderIndex: true } }
          },
          orderBy: { criterion: { orderIndex: 'asc' } }
        }
      }
    });

    if (!assessment) return res.status(404).json({ error: 'Assessment tapılmadı.' });

    res.json({ ...assessment, totalScore: computeWeightedScore(assessment.scores) });
  } catch (err) { next(err); }
});

// ─── CREATE ──────────────────────────────────────────────

// POST /api/assessments — Yeni assessment yarat
router.post('/', authenticate, async (req, res, next) => {
  try {
    const { organizationId, year } = req.body;

    // Qurum yalnız özü üçün assessment yarada bilər
    const orgId = req.user.role === 'QURUM'
      ? req.user.organizationId
      : (organizationId || req.user.organizationId);

    if (!orgId) return res.status(400).json({ error: 'Qurum seçilməyib.' });

    // Həmin il üçün mövcud draft/submitted yoxla
    const existing = await prisma.assessment.findFirst({
      where: {
        organizationId: orgId,
        year: year || 2026,
        status: { in: ['DRAFT', 'SUBMITTED', 'IN_REVIEW'] }
      }
    });

    if (existing) {
      return res.status(409).json({
        error: 'Bu qurum üçün həmin il artıq aktiv assessment mövcuddur.',
        assessmentId: existing.id
      });
    }

    const assessment = await prisma.assessment.create({
      data: {
        organizationId: orgId,
        year: year || 2026,
        createdById: req.user.id,
        status: 'DRAFT'
      },
      include: {
        organization: { select: { name: true } }
      }
    });

    await prisma.auditLog.create({
      data: {
        userId: req.user.id,
        assessmentId: assessment.id,
        action: 'ASSESSMENT_CREATED',
        details: { organizationId: orgId, year: assessment.year }
      }
    });

    res.status(201).json(assessment);
  } catch (err) { next(err); }
});

// ─── ANSWERS ─────────────────────────────────────────────

// POST /api/assessments/:id/answers — Cavabları saxla (batch)
router.post('/:id/answers', authenticate, ownsAssessment, async (req, res, next) => {
  try {
    const assessment = await prisma.assessment.findUnique({ where: { id: req.params.id } });
    if (!assessment) return res.status(404).json({ error: 'Assessment tapılmadı.' });
    if (!['DRAFT'].includes(assessment.status)) {
      return res.status(400).json({ error: 'Yalnız DRAFT statuslu assessmentə cavab yazıla bilər.' });
    }

    const { answers } = req.body; // [{ questionId, textValue, selectedOptionIds, numberValue, isNA, optionId }]

    if (!Array.isArray(answers) || answers.length === 0) {
      return res.status(400).json({ error: 'Cavablar siyahısı boşdur.' });
    }

    // Upsert — mövcuddursa yenilə, yoxdursa əlavə et
    const upsertOps = answers.map(a =>
      prisma.answer.upsert({
        where: { assessmentId_questionId: { assessmentId: req.params.id, questionId: a.questionId } },
        create: {
          assessmentId: req.params.id,
          questionId:   a.questionId,
          textValue:    a.textValue   || null,
          selectedOptionIds: a.selectedOptionIds || [],
          numberValue:  a.numberValue !== undefined ? a.numberValue : null,
          isNA:         a.isNA || false,
          optionId:     a.optionId || null
        },
        update: {
          textValue:    a.textValue   || null,
          selectedOptionIds: a.selectedOptionIds || [],
          numberValue:  a.numberValue !== undefined ? a.numberValue : null,
          isNA:         a.isNA || false,
          optionId:     a.optionId || null
        }
      })
    );

    await prisma.$transaction(upsertOps);

    // Assessment updatedAt-i yenilə
    await prisma.assessment.update({
      where: { id: req.params.id },
      data: { updatedAt: new Date() }
    });

    res.json({ saved: answers.length });
  } catch (err) { next(err); }
});

// ─── SUBMIT ──────────────────────────────────────────────

// POST /api/assessments/:id/submit — Qurumun göndərməsi
router.post('/:id/submit', authenticate, ownsAssessment, async (req, res, next) => {
  try {
    const assessment = await prisma.assessment.findUnique({
      where: { id: req.params.id },
      include: { answers: true }
    });

    if (!assessment) return res.status(404).json({ error: 'Assessment tapılmadı.' });
    if (assessment.status !== 'DRAFT') {
      return res.status(400).json({ error: 'Yalnız DRAFT statuslu assessment göndərilə bilər.' });
    }

    // Sistem ballarını hesabla
    const scores = await calculateScores(req.params.id);

    // Hər kriteriya üçün CriterionScore upsert
    const scoreOps = scores.map(s =>
      prisma.criterionScore.upsert({
        where: { assessmentId_criterionId: { assessmentId: req.params.id, criterionId: s.criterionId } },
        create: { assessmentId: req.params.id, criterionId: s.criterionId, systemScore: s.score },
        update: { systemScore: s.score }
      })
    );

    await prisma.$transaction([
      ...scoreOps,
      prisma.assessment.update({
        where: { id: req.params.id },
        data: { status: 'SUBMITTED', submittedAt: new Date() }
      })
    ]);

    await prisma.auditLog.create({
      data: {
        userId: req.user.id,
        assessmentId: req.params.id,
        action: 'ASSESSMENT_SUBMITTED',
        details: { scoreCount: scores.length }
      }
    });

    res.json({ message: 'Assessment uğurla göndərildi.', status: 'SUBMITTED' });
  } catch (err) { next(err); }
});

// ─── REVIEW & APPROVE ────────────────────────────────────

// POST /api/assessments/:id/review — Admin nəzərdən keçirməyə başlayır
router.post('/:id/review', authenticate, isReviewer, async (req, res, next) => {
  try {
    const assessment = await prisma.assessment.update({
      where: { id: req.params.id, status: 'SUBMITTED' },
      data: { status: 'IN_REVIEW', reviewedById: req.user.id }
    });

    await prisma.auditLog.create({
      data: {
        userId: req.user.id,
        assessmentId: req.params.id,
        action: 'REVIEW_STARTED'
      }
    });

    res.json(assessment);
  } catch (err) { next(err); }
});

// PUT /api/assessments/:id/scores — Admin bal dəyişir
router.put('/:id/scores', authenticate, isReviewer, async (req, res, next) => {
  try {
    const { scores } = req.body;
    // scores: [{ criterionId, adminScore, justification }]

    if (!Array.isArray(scores)) return res.status(400).json({ error: 'scores massivi tələb olunur.' });

    const ops = scores.map(s =>
      prisma.criterionScore.upsert({
        where: { assessmentId_criterionId: { assessmentId: req.params.id, criterionId: s.criterionId } },
        create: {
          assessmentId: req.params.id,
          criterionId:  s.criterionId,
          adminScore:   s.adminScore,
          justification: s.justification || null
        },
        update: {
          adminScore:   s.adminScore,
          justification: s.justification || null
        }
      })
    );

    await prisma.$transaction(ops);

    await prisma.auditLog.create({
      data: {
        userId: req.user.id,
        assessmentId: req.params.id,
        action: 'SCORES_UPDATED',
        details: { scores: scores.map(s => ({ criterionId: s.criterionId, adminScore: s.adminScore })) }
      }
    });

    res.json({ updated: scores.length });
  } catch (err) { next(err); }
});

// POST /api/assessments/:id/approve — Təsdiq
router.post('/:id/approve', authenticate, isReviewer, async (req, res, next) => {
  try {
    const { reviewNote } = req.body;

    const assessment = await prisma.assessment.update({
      where: { id: req.params.id },
      data: {
        status: 'APPROVED',
        approvedAt: new Date(),
        reviewedAt: new Date(),
        reviewedById: req.user.id,
        reviewNote: reviewNote || null
      }
    });

    await prisma.auditLog.create({
      data: {
        userId: req.user.id,
        assessmentId: req.params.id,
        action: 'ASSESSMENT_APPROVED',
        details: { reviewNote }
      }
    });

    res.json({ message: 'Assessment təsdiqləndi.', assessment });
  } catch (err) { next(err); }
});

// POST /api/assessments/:id/reject — Rədd et
router.post('/:id/reject', authenticate, isReviewer, async (req, res, next) => {
  try {
    const { reviewNote } = req.body;
    if (!reviewNote) return res.status(400).json({ error: 'Rədd səbəbi tələb olunur.' });

    const assessment = await prisma.assessment.update({
      where: { id: req.params.id },
      data: {
        status: 'REJECTED',
        reviewedAt: new Date(),
        reviewedById: req.user.id,
        reviewNote
      }
    });

    await prisma.auditLog.create({
      data: {
        userId: req.user.id,
        assessmentId: req.params.id,
        action: 'ASSESSMENT_REJECTED',
        details: { reviewNote }
      }
    });

    res.json({ message: 'Assessment rədd edildi.' });
  } catch (err) { next(err); }
});

// ─── HELPER ──────────────────────────────────────────────
function computeWeightedScore(scores) {
  if (!scores?.length) return null;
  let total = 0;
  for (const s of scores) {
    const bal = s.adminScore ?? s.systemScore ?? 0;
    total += bal * (s.criterion?.weight ?? 0);
  }
  return Math.round(total * 100) / 100;
}

module.exports = router;
