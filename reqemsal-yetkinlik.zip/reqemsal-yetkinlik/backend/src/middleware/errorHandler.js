// src/middleware/errorHandler.js
const errorHandler = (err, req, res, next) => {
  console.error(`[ERROR] ${req.method} ${req.path}:`, err);

  // Prisma xətaları
  if (err.code === 'P2002') {
    return res.status(409).json({ error: 'Bu məlumat artıq mövcuddur.' });
  }
  if (err.code === 'P2025') {
    return res.status(404).json({ error: 'Qeyd tapılmadı.' });
  }

  // Validation xətaları
  if (err.name === 'ValidationError') {
    return res.status(400).json({ error: err.message });
  }

  // Default
  const status = err.status || err.statusCode || 500;
  const message = status < 500 ? err.message : 'Daxili server xətası.';
  res.status(status).json({ error: message });
};

module.exports = { errorHandler };
