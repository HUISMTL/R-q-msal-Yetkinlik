// src/pages/QurumDashboard.tsx
import { useQuery, useMutation } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { assessmentsApi, criteriaApi } from '../api/services';
import { useAuth } from '../hooks/useAuth';
import toast from 'react-hot-toast';

export default function QurumDashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const { data: assessments } = useQuery({
    queryKey: ['assessments-qurum'],
    queryFn: () => assessmentsApi.list({ year: 2026 }).then(r => r.data)
  });
  const { data: criteria } = useQuery({
    queryKey: ['criteria'],
    queryFn: () => criteriaApi.list().then(r => r.data)
  });

  const current = assessments?.[0];
  const createMutation = useMutation({
    mutationFn: () => assessmentsApi.create(),
    onSuccess: (r) => navigate(`/assessment/${r.data.id}`),
    onError: (err: any) => {
      const existId = err?.response?.data?.assessmentId;
      if (existId) navigate(`/assessment/${existId}`);
      else toast.error(err?.response?.data?.error || 'Xəta baş verdi.');
    }
  });

  const STATUS_LABELS: Record<string, { label: string; color: string; bg: string }> = {
    DRAFT:     { label: 'Doldurulur', color: '#1a4fa0', bg: '#deeafd' },
    SUBMITTED: { label: 'Gözləyir', color: '#b45309', bg: '#fef3c7' },
    IN_REVIEW: { label: 'Nəzərdən keçirilir', color: '#0e7490', bg: '#cffafe' },
    APPROVED:  { label: 'Təsdiqləndi', color: '#047857', bg: '#d1fae5' },
    REJECTED:  { label: 'Rədd edildi', color: '#b91c1c', bg: '#fee2e2' },
  };
  const st = current ? STATUS_LABELS[current.status] : null;

  return (
    <div style={{ padding: '1.75rem', background: '#f0f4fa', minHeight: 'calc(100vh - 56px)' }}>
      <div style={{ marginBottom: '1.5rem' }}>
        <div style={{ fontSize: 20, fontWeight: 700, letterSpacing: '-.03em', color: '#0f1117' }}>
          {user?.organization?.name || 'Qurumum'}
        </div>
        <div style={{ fontSize: 12, color: '#6b7280', marginTop: 3 }}>Self-assessment vəziyyəti · 2026</div>
      </div>

      {/* Status cards */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 14, marginBottom: '1.75rem' }}>
        <div style={{ background: '#103570', border: '1px solid #1a4fa0', borderRadius: 12, padding: '1.1rem 1.25rem' }}>
          <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: '.08em', textTransform: 'uppercase', color: 'rgba(255,255,255,.6)', marginBottom: '.4rem' }}>Cari Bal</div>
          <div style={{ fontSize: 26, fontWeight: 700, color: '#fff' }}>{current?.totalScore?.toFixed(2) ?? '—'}</div>
          <div style={{ fontSize: 11, color: 'rgba(255,255,255,.5)', marginTop: 3 }}>5.00 üzərindən</div>
        </div>
        <div style={{ background: '#fff', border: '1px solid #e5e7eb', borderRadius: 12, padding: '1.1rem 1.25rem' }}>
          <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: '.08em', textTransform: 'uppercase', color: '#6b7280', marginBottom: '.4rem' }}>Status</div>
          {st ? (
            <span style={{ fontSize: 13, fontWeight: 600, padding: '3px 10px', borderRadius: 20, background: st.bg, color: st.color }}>{st.label}</span>
          ) : (
            <div style={{ fontSize: 13, color: '#9ca3af' }}>Assessment yoxdur</div>
          )}
        </div>
        <div style={{ background: '#fff', border: '1px solid #e5e7eb', borderRadius: 12, padding: '1.1rem 1.25rem' }}>
          <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: '.08em', textTransform: 'uppercase', color: '#6b7280', marginBottom: '.4rem' }}>Kriteriya</div>
          <div style={{ fontSize: 26, fontWeight: 700, color: '#0f1117' }}>{criteria?.length ?? 12}</div>
          <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 3 }}>Qiymətləndirmə sahəsi</div>
        </div>
      </div>

      {/* Action */}
      <div style={{ background: '#fff', border: '1px solid #e5e7eb', borderRadius: 12, overflow: 'hidden', marginBottom: 16 }}>
        <div style={{ padding: '.9rem 1.25rem', borderBottom: '1px solid #e5e7eb', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span style={{ fontSize: 13, fontWeight: 600 }}>Assessment</span>
          {(!current || current.status === 'DRAFT') && (
            <button onClick={() => current ? navigate(`/assessment/${current.id}`) : createMutation.mutate()}
              style={{ padding: '7px 16px', background: '#1a4fa0', color: '#fff', border: 'none', borderRadius: 8, fontSize: 12, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit' }}>
              {current ? 'Davam et' : 'Başla'}
            </button>
          )}
        </div>
        <div style={{ padding: '1.25rem' }}>
          {criteria?.map(c => {
            const done = false; // real: check if answers exist for this criterion
            return (
              <div key={c.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '8px 10px', borderRadius: 8, marginBottom: 6, background: done ? '#d1fae5' : '#f9fafb' }}>
                <div style={{ width: 6, height: 6, borderRadius: '50%', background: done ? '#10b981' : '#d1d5db', flexShrink: 0 }} />
                <span style={{ fontSize: 12, fontWeight: 500, flex: 1, color: done ? '#047857' : '#4b5563' }}>{c.nameAz}</span>
                <span style={{ fontSize: 10, color: '#6b7280' }}>Çəki: {(c.weight * 100).toFixed(0)}%</span>
              </div>
            );
          })}
        </div>
      </div>

      {current?.status === 'APPROVED' && (
        <div style={{ background: '#d1fae5', border: '1px solid #a7f3d0', borderRadius: 12, padding: '1rem 1.25rem' }}>
          <div style={{ fontSize: 13, fontWeight: 600, color: '#047857', marginBottom: 4 }}>✓ Assessment təsdiqləndi</div>
          <div style={{ fontSize: 12, color: '#065f46' }}>Final bal: {current.totalScore?.toFixed(2)} · {new Date(current.approvedAt!).toLocaleDateString('az-AZ')}</div>
          {current.reviewNote && <div style={{ fontSize: 12, color: '#065f46', marginTop: 4 }}>Admin qeydi: {current.reviewNote}</div>}
        </div>
      )}
    </div>
  );
}
