// src/routes/criteria.js
const express = require('express');
const { PrismaClient } = require('@prisma/client');
const { authenticate } = require('../middleware/auth');
const router = express.Router();
const prisma = new PrismaClient();

router.get('/', authenticate, async (req, res, next) => {
  try {
    const criteria = await prisma.criterion.findMany({
      where: { active: true },
      include: {
        questions: {
          include: { options: { orderBy: { orderIndex: 'asc' } } },
          orderBy: { orderIndex: 'asc' }
        }
      },
      orderBy: { orderIndex: 'asc' }
    });
    res.json(criteria);
  } catch (err) { next(err); }
});

module.exports = router;

// ─────────────────────────────────────────────────────────
// src/routes/audit.js — ayrıca fayl kimi export olunur
