// src/routes/organizations.js
const express = require('express');
const { PrismaClient } = require('@prisma/client');
const { authenticate, isAdmin } = require('../middleware/auth');
const router = express.Router();
const prisma = new PrismaClient();

router.get('/', authenticate, async (req, res, next) => {
  try {
    const orgs = await prisma.organization.findMany({
      where: { active: true },
      orderBy: [{ group: 'asc' }, { name: 'asc' }]
    });
    res.json(orgs);
  } catch (err) { next(err); }
});

router.post('/', authenticate, isAdmin, async (req, res, next) => {
  try {
    const { name, shortName, group, website } = req.body;
    if (!name || !group) return res.status(400).json({ error: 'Ad və qrup tələb olunur.' });
    const org = await prisma.organization.create({ data: { name, shortName, group, website } });
    res.status(201).json(org);
  } catch (err) { next(err); }
});

router.put('/:id', authenticate, isAdmin, async (req, res, next) => {
  try {
    const org = await prisma.organization.update({
      where: { id: req.params.id },
      data: req.body
    });
    res.json(org);
  } catch (err) { next(err); }
});

module.exports = router;
