// src/pages/ReportsPage.tsx
import { useQuery } from '@tanstack/react-query';
import { reportsApi } from '../api/services';

export default function ReportsPage() {
  const { data, isLoading } = useQuery({
    queryKey: ['reports-summary'],
    queryFn: () => reportsApi.summary(2026).then(r => r.data)
  });

  if (isLoading) return <div style={{ padding: '2rem', color: '#6b7280' }}>Yüklənir...</div>;

  return (
    <div style={{ padding: '1.75rem', background: '#f0f4fa', minHeight: 'calc(100vh - 56px)' }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '1.5rem' }}>
        <div>
          <div style={{ fontSize: 20, fontWeight: 700, letterSpacing: '-.03em', color: '#0f1117' }}>Statistik Hesabatlar</div>
          <div style={{ fontSize: 12, color: '#6b7280', marginTop: 3 }}>Azərbaycan · 2026 · {data?.total ?? 0} qurum</div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button style={{ padding: '7px 14px', background: 'transparent', border: '1px solid #e5e7eb', borderRadius: 8, fontSize: 12, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit', color: '#4b5563', display: 'flex', alignItems: 'center', gap: 5 }}>
            <svg width="12" height="12" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
            Excel
          </button>
          <button style={{ padding: '7px 14px', background: '#1a4fa0', color: '#fff', border: 'none', borderRadius: 8, fontSize: 12, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit', display: 'flex', alignItems: 'center', gap: 5 }}>
            <svg width="12" height="12" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
            PDF
          </button>
        </div>
      </div>

      {/* Summary stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: '1.75rem' }}>
        {[
          { label: 'Ölkə Orta', value: data?.countryAverage?.toFixed(2) ?? '—', sub: 'Hədəf 2027: 3.65', primary: true },
          { label: 'Ən Yüksək', value: data?.ranking?.[0]?.score?.toFixed(2) ?? '—', sub: data?.ranking?.[0]?.orgName, green: true },
          { label: 'Ən Aşağı',  value: data?.ranking?.at(-1)?.score?.toFixed(2) ?? '—', sub: data?.ranking?.at(-1)?.orgName, red: true },
          { label: 'Boşluq',    value: ((data?.ranking?.[0]?.score ?? 0) - (data?.ranking?.at(-1)?.score ?? 0)).toFixed(2), sub: 'Maks–Min fərqi' },
        ].map(c => (
          <div key={c.label} style={{ background: c.primary ? '#103570' : '#fff', border: `1px solid ${c.primary ? '#1a4fa0' : '#e5e7eb'}`, borderRadius: 12, padding: '1.1rem 1.25rem', boxShadow: '0 1px 3px rgba(10,22,40,.06)' }}>
            <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: '.08em', textTransform: 'uppercase' as const, color: c.primary ? 'rgba(255,255,255,.6)' : '#6b7280', marginBottom: '.4rem' }}>{c.label}</div>
            <div style={{ fontSize: 26, fontWeight: 700, letterSpacing: '-.04em', lineHeight: 1, color: c.primary ? '#fff' : c.green ? '#047857' : c.red ? '#b91c1c' : '#0f1117' }}>{c.value}</div>
            {c.sub && <div style={{ fontSize: 11, color: c.primary ? 'rgba(255,255,255,.5)' : '#9ca3af', marginTop: 3, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{c.sub}</div>}
          </div>
        ))}
      </div>

      {/* Criteria table */}
      <div style={{ background: '#fff', border: '1px solid #e5e7eb', borderRadius: 12, overflow: 'hidden', marginBottom: 16 }}>
        <div style={{ padding: '.9rem 1.25rem', borderBottom: '1px solid #e5e7eb' }}>
          <span style={{ fontSize: 13, fontWeight: 600 }}>Kriteriya üzrə Ölkə Statistikası (D1–D12)</span>
        </div>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr>{['Kriteriya', 'Çəki', 'Ölkə Orta', 'Hədəf 2027', 'Hədəf 2030', 'Boşluq'].map(h => (
              <th key={h} style={{ padding: '.65rem 1rem', textAlign: 'left', fontSize: 10, fontWeight: 700, letterSpacing: '.08em', textTransform: 'uppercase' as const, color: '#6b7280', background: '#f9fafb', borderBottom: '1px solid #e5e7eb' }}>{h}</th>
            ))}</tr>
          </thead>
          <tbody>
            {data?.criterionAverages?.map((c: any) => {
              const target2027 = Math.min(5, c.average * 1.35);
              const target2030 = Math.min(5, c.average * 1.85);
              const gap = 5 - c.average;
              return (
                <tr key={c.code}>
                  <td style={{ padding: '.8rem 1rem', borderBottom: '1px solid #f3f4f6', fontSize: 12, fontWeight: 600, color: '#1e2433' }}>
                    <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, background: '#f0f6ff', color: '#1a4fa0', border: '1px solid #b8d4f8', borderRadius: 4, padding: '1px 6px', marginRight: 6 }}>{c.code}</span>
                    {c.name}
                  </td>
                  <td style={{ padding: '.8rem 1rem', borderBottom: '1px solid #f3f4f6', fontFamily: 'JetBrains Mono, monospace', fontSize: 12 }}>{(c.weight * 100).toFixed(0)}%</td>
                  <td style={{ padding: '.8rem 1rem', borderBottom: '1px solid #f3f4f6' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 12, fontWeight: 600, width: 28, color: c.average >= 3.5 ? '#047857' : c.average >= 2 ? '#1a4fa0' : '#b91c1c' }}>{c.average.toFixed(2)}</span>
                      <div style={{ width: 80, height: 4, background: '#e5e7eb', borderRadius: 2, overflow: 'hidden' }}>
                        <div style={{ height: '100%', borderRadius: 2, background: c.average >= 3.5 ? '#10b981' : c.average >= 2.5 ? '#1e63c8' : '#f59e0b', width: `${(c.average / 5) * 100}%` }} />
                      </div>
                    </div>
                  </td>
                  <td style={{ padding: '.8rem 1rem', borderBottom: '1px solid #f3f4f6', fontFamily: 'JetBrains Mono, monospace', fontSize: 12, color: '#1a4fa0' }}>{target2027.toFixed(2)}</td>
                  <td style={{ padding: '.8rem 1rem', borderBottom: '1px solid #f3f4f6', fontFamily: 'JetBrains Mono, monospace', fontSize: 12, color: '#047857' }}>{target2030.toFixed(2)}</td>
                  <td style={{ padding: '.8rem 1rem', borderBottom: '1px solid #f3f4f6', fontFamily: 'JetBrains Mono, monospace', fontSize: 12, color: '#9ca3af' }}>{gap.toFixed(2)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Rankings */}
      {data?.ranking && (
        <div style={{ background: '#fff', border: '1px solid #e5e7eb', borderRadius: 12, overflow: 'hidden' }}>
          <div style={{ padding: '.9rem 1.25rem', borderBottom: '1px solid #e5e7eb' }}>
            <span style={{ fontSize: 13, fontWeight: 600 }}>Qurum Sıralaması</span>
          </div>
          <div style={{ padding: '1rem' }}>
            {data.ranking.map((r: any, i: number) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '8px 10px', borderRadius: 8, marginBottom: 4, background: i === 0 ? '#f0f6ff' : '#f9fafb' }}>
                <div style={{ width: 24, height: 24, borderRadius: '50%', background: i === 0 ? '#1a4fa0' : i === 1 ? '#6da3ee' : i === 2 ? '#b8d4f8' : '#e5e7eb', color: i < 3 ? '#fff' : '#6b7280', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 700, flexShrink: 0 }}>
                  {i + 1}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 12, fontWeight: 600, color: '#0f1117' }}>{r.orgName}</div>
                  <div style={{ fontSize: 10, color: '#9ca3af' }}>{r.group}</div>
                </div>
                <div style={{ width: 120, height: 5, background: '#e5e7eb', borderRadius: 3, overflow: 'hidden' }}>
                  <div style={{ height: '100%', background: '#1e63c8', borderRadius: 3, width: `${(r.score / 5) * 100}%` }} />
                </div>
                <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 13, fontWeight: 700, color: '#0f1117', width: 36, textAlign: 'right' as const }}>{r.score.toFixed(2)}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
