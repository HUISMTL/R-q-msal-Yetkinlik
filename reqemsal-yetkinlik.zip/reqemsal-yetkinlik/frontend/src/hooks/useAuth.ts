// src/hooks/useAuth.ts
import { create } from 'zustand';
import { authApi, type User } from '../api/services';

interface AuthState {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  init: () => Promise<void>;
}

export const useAuth = create<AuthState>((set) => ({
  user:      JSON.parse(localStorage.getItem('user') || 'null'),
  token:     localStorage.getItem('token'),
  isLoading: false,

  init: async () => {
    const token = localStorage.getItem('token');
    if (!token) return;
    try {
      const { data } = await authApi.me();
      set({ user: data, token });
      localStorage.setItem('user', JSON.stringify(data));
    } catch {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      set({ user: null, token: null });
    }
  },

  login: async (username, password) => {
    set({ isLoading: true });
    try {
      const { data } = await authApi.login(username, password);
      localStorage.setItem('token', data.token);
      localStorage.setItem('user', JSON.stringify(data.user));
      set({ user: data.user, token: data.token, isLoading: false });
    } catch (err) {
      set({ isLoading: false });
      throw err;
    }
  },

  logout: async () => {
    try { await authApi.logout(); } catch { /* ignore */ }
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    set({ user: null, token: null });
  }
}));

// ─── Role helpers ─────────────────────────────────────────
export const isAdmin     = (user: User | null) => ['SUPER_ADMIN', 'ADMIN'].includes(user?.role || '');
export const isReviewer  = (user: User | null) => ['SUPER_ADMIN', 'ADMIN', 'QIYMETLENDIRICI'].includes(user?.role || '');
export const isAnalyst   = (user: User | null) => ['SUPER_ADMIN', 'ADMIN', 'EKSPERT', 'QIYMETLENDIRICI'].includes(user?.role || '');
export const isQurum     = (user: User | null) => user?.role === 'QURUM';
