// src/pages/UsersPage.tsx
import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { usersApi, orgsApi, type User } from '../api/services';
import toast from 'react-hot-toast';

const ROLE_CFG: Record<string, { label: string; bg: string; color: string }> = {
  SUPER_ADMIN:     { label: 'Super Admin',     bg: '#deeafd', color: '#1a4fa0' },
  ADMIN:           { label: 'Admin',           bg: '#deeafd', color: '#1a4fa0' },
  EKSPERT:         { label: 'Ekspert',         bg: '#fef3c7', color: '#b45309' },
  QIYMETLENDIRICI: { label: 'Qiymətləndiricı', bg: '#f3e8ff', color: '#6b21a8' },
  QURUM:           { label: 'Qurum',           bg: '#d1fae5', color: '#047857' },
};

export default function UsersPage() {
  const qc = useQueryClient();
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ username: '', password: '', fullName: '', role: 'QURUM', organizationId: '', email: '' });

  const { data: users } = useQuery({ queryKey: ['users'], queryFn: () => usersApi.list().then(r => r.data) });
  const { data: orgs  } = useQuery({ queryKey: ['orgs'],  queryFn: () => orgsApi.list().then(r => r.data) });

  const createMut = useMutation({
    mutationFn: () => usersApi.create(form as any),
    onSuccess: () => {
      toast.success('İstifadəçi yaradıldı.');
      qc.invalidateQueries({ queryKey: ['users'] });
      setShowModal(false);
      setForm({ username: '', password: '', fullName: '', role: 'QURUM', organizationId: '', email: '' });
    },
    onError: (err: any) => toast.error(err?.response?.data?.error || 'Xəta baş verdi.')
  });

  const deactivateMut = useMutation({
    mutationFn: (id: string) => usersApi.deactivate(id),
    onSuccess: () => { toast.success('İstifadəçi deaktiv edildi.'); qc.invalidateQueries({ queryKey: ['users'] }); }
  });

  return (
    <div style={{ padding: '1.75rem', background: '#f0f4fa', minHeight: 'calc(100vh - 56px)' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '1.5rem' }}>
        <div>
          <div style={{ fontSize: 20, fontWeight: 700, letterSpacing: '-.03em', color: '#0f1117' }}>İstifadəçi İdarəetməsi</div>
          <div style={{ fontSize: 12, color: '#6b7280', marginTop: 3 }}>Bütün istifadəçilər admin tərəfindən yaradılır. Rol sistemi daxilən idarə edilir.</div>
        </div>
        <button onClick={() => setShowModal(true)}
          style={{ padding: '7px 16px', background: '#1a4fa0', color: '#fff', border: 'none', borderRadius: 8, fontSize: 12, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit', display: 'flex', alignItems: 'center', gap: 6 }}>
          <svg width="12" height="12" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4"/></svg>
          Yeni İstifadəçi
        </button>
      </div>

      {/* Info banner */}
      <div style={{ background: '#f0f6ff', border: '1px solid #b8d4f8', borderRadius: 8, padding: '.75rem 1rem', marginBottom: '1.25rem', fontSize: 12, color: '#1a4fa0', display: 'flex', alignItems: 'flex-start', gap: 8 }}>
        <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2} style={{ flexShrink: 0, marginTop: 1 }}><path strokeLinecap="round" strokeLinejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        <span><strong>Rol bölgüsü:</strong> İstifadəçilər platforma üzərindən birbaşa öz rollarını görə bilmirlər. Qurum yalnız öz self-assessmentini görür, ekspert analitik panelə çıxır, admin hamısına çıxış imkanı əldə edir.</span>
      </div>

      {/* User cards */}
      {users?.map((u: User) => {
        const rc = ROLE_CFG[u.role] || { label: u.role, bg: '#f3f4f6', color: '#4b5563' };
        const initials = u.fullName.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
        return (
          <div key={u.id} style={{ background: u.active ? '#fff' : '#f9fafb', border: '1px solid #e5e7eb', borderRadius: 12, padding: '1rem 1.25rem', display: 'flex', alignItems: 'center', gap: 14, marginBottom: 10, boxShadow: '0 1px 3px rgba(10,22,40,.06)', opacity: u.active ? 1 : .6 }}>
            <div style={{ width: 40, height: 40, borderRadius: '50%', background: u.active ? '#1e63c8' : '#9ca3af', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, fontWeight: 700, flexShrink: 0 }}>
              {initials}
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: '#0f1117' }}>{u.fullName}</div>
              <div style={{ fontSize: 11, color: '#6b7280' }}>
                {u.username}{u.email ? ` · ${u.email}` : ''}
              </div>
              {u.organization && (
                <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 1 }}>{u.organization.name}</div>
              )}
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              {!u.active && <span style={{ fontSize: 10, fontWeight: 600, background: '#fee2e2', color: '#b91c1c', padding: '2px 8px', borderRadius: 20 }}>Deaktiv</span>}
              <span style={{ fontSize: 11, fontWeight: 600, padding: '3px 11px', borderRadius: 20, background: rc.bg, color: rc.color }}>{rc.label}</span>
              {u.active && (
                <button onClick={() => { if (window.confirm(`${u.fullName} deaktiv edilsin?`)) deactivateMut.mutate(u.id); }}
                  style={{ padding: '5px 10px', background: 'transparent', border: '1px solid #e5e7eb', borderRadius: 6, fontSize: 11, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit', color: '#b91c1c' }}>
                  Deaktiv et
                </button>
              )}
            </div>
          </div>
        );
      })}

      {/* Create modal */}
      {showModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(10,22,40,.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 500 }}>
          <div style={{ background: '#fff', borderRadius: 16, padding: '2rem', width: 480, boxShadow: '0 20px 60px rgba(10,22,40,.3)' }}>
            <div style={{ fontSize: 17, fontWeight: 700, color: '#0f1117', marginBottom: '1.5rem' }}>Yeni İstifadəçi Yarat</div>

            {[
              { label: 'Ad Soyad', key: 'fullName', type: 'text', placeholder: 'Əli Əliyev' },
              { label: 'İstifadəçi adı', key: 'username', type: 'text', placeholder: 'eli.eliyev' },
              { label: 'E-mail (ixtiyari)', key: 'email', type: 'email', placeholder: 'eli@gov.az' },
              { label: 'Şifrə (min. 8 simvol)', key: 'password', type: 'password', placeholder: '••••••••' },
            ].map(f => (
              <div key={f.key} style={{ marginBottom: '1rem' }}>
                <label style={{ display: 'block', fontSize: 11, fontWeight: 600, color: '#374151', marginBottom: 5 }}>{f.label}</label>
                <input type={f.type} placeholder={f.placeholder}
                  value={(form as any)[f.key]} onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))}
                  style={{ width: '100%', padding: '9px 12px', border: '1.5px solid #e5e7eb', borderRadius: 8, fontFamily: 'inherit', fontSize: 13, outline: 'none' }}
                />
              </div>
            ))}

            <div style={{ marginBottom: '1rem' }}>
              <label style={{ display: 'block', fontSize: 11, fontWeight: 600, color: '#374151', marginBottom: 5 }}>Rol</label>
              <select value={form.role} onChange={e => setForm(p => ({ ...p, role: e.target.value }))}
                style={{ width: '100%', padding: '9px 12px', border: '1.5px solid #e5e7eb', borderRadius: 8, fontFamily: 'inherit', fontSize: 13, outline: 'none', background: '#fff' }}>
                {Object.entries(ROLE_CFG).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
              </select>
            </div>

            {form.role === 'QURUM' && (
              <div style={{ marginBottom: '1rem' }}>
                <label style={{ display: 'block', fontSize: 11, fontWeight: 600, color: '#374151', marginBottom: 5 }}>Qurum</label>
                <select value={form.organizationId} onChange={e => setForm(p => ({ ...p, organizationId: e.target.value }))}
                  style={{ width: '100%', padding: '9px 12px', border: '1.5px solid #e5e7eb', borderRadius: 8, fontFamily: 'inherit', fontSize: 13, outline: 'none', background: '#fff' }}>
                  <option value="">— Seçin —</option>
                  {orgs?.map((o: any) => <option key={o.id} value={o.id}>{o.name}</option>)}
                </select>
              </div>
            )}

            <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: '1.5rem' }}>
              <button onClick={() => setShowModal(false)}
                style={{ padding: '8px 16px', background: 'transparent', border: '1px solid #e5e7eb', borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit', color: '#4b5563' }}>
                Ləğv et
              </button>
              <button onClick={() => createMut.mutate()} disabled={createMut.isPending}
                style={{ padding: '8px 20px', background: '#1a4fa0', color: '#fff', border: 'none', borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit' }}>
                {createMut.isPending ? 'Yaradılır...' : 'Yarat'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
