// src/routes/users.js
const express = require('express');
const bcrypt = require('bcryptjs');
const { body, validationResult } = require('express-validator');
const { PrismaClient } = require('@prisma/client');
const { authenticate, isAdmin } = require('../middleware/auth');

const router = express.Router();
const prisma = new PrismaClient();

// GET /api/users — Bütün istifadəçilər (admin)
router.get('/', authenticate, isAdmin, async (req, res, next) => {
  try {
    const users = await prisma.user.findMany({
      select: {
        id: true, username: true, email: true, fullName: true,
        role: true, active: true, lastLoginAt: true, createdAt: true,
        organization: { select: { id: true, name: true, group: true } }
      },
      orderBy: { createdAt: 'desc' }
    });
    res.json(users);
  } catch (err) { next(err); }
});

// POST /api/users — Yeni istifadəçi yarat (admin)
router.post('/',
  authenticate, isAdmin,
  [
    body('username').trim().isLength({ min: 3 }).withMessage('İstifadəçi adı ən az 3 simvol olmalıdır.'),
    body('password').isLength({ min: 8 }).withMessage('Şifrə ən az 8 simvol olmalıdır.'),
    body('fullName').trim().notEmpty().withMessage('Ad tələb olunur.'),
    body('role').isIn(['SUPER_ADMIN','ADMIN','EKSPERT','QIYMETLENDIRICI','QURUM']).withMessage('Keçərsiz rol.'),
  ],
  async (req, res, next) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

      const { username, password, email, fullName, role, organizationId } = req.body;

      // QURUM rolu üçün organization məcburidir
      if (role === 'QURUM' && !organizationId) {
        return res.status(400).json({ error: 'Qurum rolu üçün qurum seçimi məcburidir.' });
      }

      const passwordHash = await bcrypt.hash(password, 12);

      const user = await prisma.user.create({
        data: { username, email, passwordHash, fullName, role, organizationId },
        select: {
          id: true, username: true, email: true, fullName: true, role: true,
          organization: { select: { id: true, name: true } }
        }
      });

      await prisma.auditLog.create({
        data: {
          userId: req.user.id,
          action: 'USER_CREATED',
          details: { newUserId: user.id, username: user.username, role: user.role }
        }
      });

      res.status(201).json(user);
    } catch (err) { next(err); }
  }
);

// PUT /api/users/:id — İstifadəçini yenilə
router.put('/:id', authenticate, isAdmin, async (req, res, next) => {
  try {
    const { fullName, email, role, organizationId, active } = req.body;
    const data = {};

    if (fullName)       data.fullName = fullName;
    if (email)          data.email = email;
    if (role)           data.role = role;
    if (organizationId !== undefined) data.organizationId = organizationId || null;
    if (active !== undefined) data.active = active;

    // Şifrə yeniləmə
    if (req.body.password) {
      data.passwordHash = await bcrypt.hash(req.body.password, 12);
    }

    const user = await prisma.user.update({
      where: { id: req.params.id },
      data,
      select: { id: true, username: true, fullName: true, role: true, active: true }
    });

    await prisma.auditLog.create({
      data: {
        userId: req.user.id,
        action: 'USER_UPDATED',
        details: { targetUserId: req.params.id, changes: Object.keys(data) }
      }
    });

    res.json(user);
  } catch (err) { next(err); }
});

// DELETE /api/users/:id — Deaktiv et (silmə yox)
router.delete('/:id', authenticate, isAdmin, async (req, res, next) => {
  try {
    if (req.params.id === req.user.id) {
      return res.status(400).json({ error: 'Öz hesabınızı deaktiv edə bilməzsiniz.' });
    }
    await prisma.user.update({
      where: { id: req.params.id },
      data: { active: false }
    });
    res.json({ message: 'İstifadəçi deaktiv edildi.' });
  } catch (err) { next(err); }
});

module.exports = router;
