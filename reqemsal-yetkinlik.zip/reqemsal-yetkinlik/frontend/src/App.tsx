// src/App.tsx
import { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from 'react-hot-toast';

import { useAuth, isQurum } from './hooks/useAuth';

import Layout           from './components/Layout';
import LoginPage        from './pages/LoginPage';
import DashboardPage    from './pages/DashboardPage';
import QurumDashboard   from './pages/QurumDashboard';
import AssessmentPage   from './pages/AssessmentPage';
import AssessmentsAdmin from './pages/AssessmentsAdmin';
import ReviewPage       from './pages/ReviewPage';
import ReportsPage      from './pages/ReportsPage';
import UsersPage        from './pages/UsersPage';
import AuditPage        from './pages/AuditPage';

const queryClient = new QueryClient({
  defaultOptions: { queries: { retry: 1, staleTime: 30_000 } }
});

function PrivateRoute({ children, roles }: { children: React.ReactNode; roles?: string[] }) {
  const { user, token } = useAuth();
  if (!token || !user) return <Navigate to="/login" replace />;
  if (roles && !roles.includes(user.role)) return <Navigate to="/" replace />;
  return <>{children}</>;
}

function RoleFallback() {
  const { user } = useAuth();
  if (isQurum(user)) return <Navigate to="/qurumum" replace />;
  return <Navigate to="/" replace />;
}

export default function App() {
  const { init } = useAuth();
  useEffect(() => { init(); }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route element={<PrivateRoute><Layout /></PrivateRoute>}>
            <Route path="/" element={
              <PrivateRoute roles={['SUPER_ADMIN','ADMIN','EKSPERT','QIYMETLENDIRICI']}>
                <DashboardPage />
              </PrivateRoute>
            } />
            <Route path="/qurumum" element={
              <PrivateRoute roles={['QURUM']}><QurumDashboard /></PrivateRoute>
            } />
            <Route path="/assessment" element={
              <PrivateRoute roles={['QURUM']}><AssessmentPage /></PrivateRoute>
            } />
            <Route path="/assessment/:id" element={
              <PrivateRoute roles={['QURUM']}><AssessmentPage /></PrivateRoute>
            } />
            <Route path="/assessments" element={
              <PrivateRoute roles={['SUPER_ADMIN','ADMIN','QIYMETLENDIRICI']}>
                <AssessmentsAdmin />
              </PrivateRoute>
            } />
            <Route path="/assessments/:id/review" element={
              <PrivateRoute roles={['SUPER_ADMIN','ADMIN','QIYMETLENDIRICI']}>
                <ReviewPage />
              </PrivateRoute>
            } />
            <Route path="/reports" element={
              <PrivateRoute roles={['SUPER_ADMIN','ADMIN','EKSPERT','QIYMETLENDIRICI']}>
                <ReportsPage />
              </PrivateRoute>
            } />
            <Route path="/users" element={
              <PrivateRoute roles={['SUPER_ADMIN','ADMIN']}><UsersPage /></PrivateRoute>
            } />
            <Route path="/audit" element={
              <PrivateRoute roles={['SUPER_ADMIN','ADMIN']}><AuditPage /></PrivateRoute>
            } />
            <Route path="*" element={<RoleFallback />} />
          </Route>
        </Routes>
      </BrowserRouter>
      <Toaster position="top-right" toastOptions={{ duration: 4000, style: { fontFamily: 'Inter, sans-serif', fontSize: '13px' } }} />
    </QueryClientProvider>
  );
}
