// src/pages/AssessmentsAdmin.tsx
import { useQuery } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { assessmentsApi, type Assessment } from '../api/services';

const STATUS_CFG: Record<string, { label: string; bg: string; color: string }> = {
  DRAFT:     { label: 'Draft',     bg: '#f3f4f6', color: '#4b5563' },
  SUBMITTED: { label: 'Gözləyir', bg: '#fef3c7', color: '#b45309' },
  IN_REVIEW: { label: 'Nəzərdə',  bg: '#cffafe', color: '#0e7490' },
  APPROVED:  { label: 'Təsdiq',   bg: '#d1fae5', color: '#047857' },
  REJECTED:  { label: 'Rədd',     bg: '#fee2e2', color: '#b91c1c' },
};

export default function AssessmentsAdmin() {
  const navigate = useNavigate();

  const { data: all, isLoading } = useQuery({
    queryKey: ['assessments-admin'],
    queryFn: () => assessmentsApi.list({ year: 2026 }).then(r => r.data)
  });

  const pending  = all?.filter(a => ['SUBMITTED', 'IN_REVIEW'].includes(a.status)) ?? [];
  const approved = all?.filter(a => a.status === 'APPROVED') ?? [];
  const rejected = all?.filter(a => a.status === 'REJECTED') ?? [];

  const Row = ({ a }: { a: Assessment }) => {
    const st = STATUS_CFG[a.status];
    return (
      <tr>
        <td style={{ padding: '.8rem 1rem', borderBottom: '1px solid #f3f4f6' }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: '#1e2433' }}>{a.organization.name}</div>
          <div style={{ fontSize: 10, color: '#9ca3af' }}>{a.organization.group?.replace(/_/g, ' ')}</div>
        </td>
        <td style={{ padding: '.8rem 1rem', borderBottom: '1px solid #f3f4f6', fontSize: 12, color: '#4b5563' }}>{a.year}</td>
        <td style={{ padding: '.8rem 1rem', borderBottom: '1px solid #f3f4f6' }}>
          <span style={{ fontSize: 10, fontWeight: 600, padding: '2px 9px', borderRadius: 20, background: st.bg, color: st.color, display: 'inline-flex', alignItems: 'center', gap: 4 }}>
            <span style={{ width: 5, height: 5, borderRadius: '50%', background: st.color, display: 'inline-block' }} />
            {st.label}
          </span>
        </td>
        <td style={{ padding: '.8rem 1rem', borderBottom: '1px solid #f3f4f6' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 12, fontWeight: 600, color: '#0f1117' }}>
              {a.totalScore?.toFixed(2) ?? '—'}
            </span>
            {a.totalScore && (
              <div style={{ width: 50, height: 4, background: '#e5e7eb', borderRadius: 2, overflow: 'hidden' }}>
                <div style={{ height: '100%', background: '#1e63c8', borderRadius: 2, width: `${(a.totalScore / 5) * 100}%` }} />
              </div>
            )}
          </div>
        </td>
        <td style={{ padding: '.8rem 1rem', borderBottom: '1px solid #f3f4f6', fontSize: 11, color: '#9ca3af', fontFamily: 'JetBrains Mono, monospace' }}>
          {a.submittedAt ? new Date(a.submittedAt).toLocaleDateString('az-AZ') : '—'}
        </td>
        <td style={{ padding: '.8rem 1rem', borderBottom: '1px solid #f3f4f6' }}>
          {['SUBMITTED', 'IN_REVIEW'].includes(a.status) && (
            <button onClick={() => navigate(`/assessments/${a.id}/review`)}
              style={{ padding: '5px 12px', background: '#1a4fa0', color: '#fff', border: 'none', borderRadius: 6, fontSize: 11, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit', display: 'inline-flex', alignItems: 'center', gap: 5 }}>
              <svg width="11" height="11" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path strokeLinecap="round" strokeLinejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
              Nəzərdən keç
            </button>
          )}
          {a.status === 'APPROVED' && (
            <button style={{ padding: '5px 12px', background: 'transparent', border: '1px solid #e5e7eb', borderRadius: 6, fontSize: 11, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit', color: '#4b5563' }}>
              Görüntülə
            </button>
          )}
        </td>
      </tr>
    );
  };

  const Section = ({ title, rows, borderColor }: { title: string; rows: Assessment[]; borderColor: string }) => (
    <div style={{ background: '#fff', border: '1px solid #e5e7eb', borderLeft: `3px solid ${borderColor}`, borderRadius: 12, overflow: 'hidden', marginBottom: 16 }}>
      <div style={{ padding: '.9rem 1.25rem', borderBottom: '1px solid #e5e7eb', display: 'flex', alignItems: 'center', gap: 8 }}>
        <span style={{ fontSize: 13, fontWeight: 600, color: '#0f1117', flex: 1 }}>{title} ({rows.length})</span>
      </div>
      {rows.length === 0 ? (
        <div style={{ padding: '1.5rem', textAlign: 'center', color: '#9ca3af', fontSize: 12 }}>Qeyd yoxdur.</div>
      ) : (
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr>{['Qurum', 'İl', 'Status', 'Bal', 'Göndərilmə', 'Əməliyyat'].map(h => (
              <th key={h} style={{ padding: '.65rem 1rem', textAlign: 'left', fontSize: 10, fontWeight: 700, letterSpacing: '.08em', textTransform: 'uppercase' as const, color: '#6b7280', background: '#f9fafb', borderBottom: '1px solid #e5e7eb' }}>{h}</th>
            ))}</tr>
          </thead>
          <tbody>{rows.map(a => <Row key={a.id} a={a} />)}</tbody>
        </table>
      )}
    </div>
  );

  if (isLoading) return <div style={{ padding: '2rem', color: '#6b7280' }}>Yüklənir...</div>;

  return (
    <div style={{ padding: '1.75rem', background: '#f0f4fa', minHeight: 'calc(100vh - 56px)' }}>
      <div style={{ marginBottom: '1.5rem' }}>
        <div style={{ fontSize: 20, fontWeight: 700, letterSpacing: '-.03em', color: '#0f1117' }}>Qiymətləndirmələr</div>
        <div style={{ fontSize: 12, color: '#6b7280', marginTop: 3 }}>Self-assessment nəticələrini nəzərdən keçirin, təsdiqləyin</div>
      </div>
      <Section title="⏳ Təsdiq Gözləyən" rows={pending}  borderColor="#f59e0b" />
      <Section title="✓ Təsdiqlənmiş"      rows={approved} borderColor="#10b981" />
      <Section title="✕ Rədd Edilmiş"      rows={rejected} borderColor="#ef4444" />
    </div>
  );
}
