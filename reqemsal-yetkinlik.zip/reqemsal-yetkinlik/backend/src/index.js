// src/index.js
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');

const authRoutes       = require('./routes/auth');
const userRoutes       = require('./routes/users');
const orgRoutes        = require('./routes/organizations');
const assessmentRoutes = require('./routes/assessments');
const criterionRoutes  = require('./routes/criteria');
const reportRoutes     = require('./routes/reports');
const auditRoutes      = require('./routes/audit');

const { errorHandler } = require('./middleware/errorHandler');

const app = express();

// ─── Security ───────────────────────────────────────────
app.use(helmet());
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:5173',
  credentials: true
}));

// ─── Rate limiting ───────────────────────────────────────
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 dəqiqə
  max: 200,
  message: { error: 'Çox sayda sorğu. Bir müddət sonra cəhd edin.' }
});

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: { error: 'Çox sayda giriş cəhdi.' }
});

app.use(limiter);
app.use(morgan('combined'));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// ─── Routes ──────────────────────────────────────────────
app.use('/api/auth',         authLimiter, authRoutes);
app.use('/api/users',        userRoutes);
app.use('/api/organizations', orgRoutes);
app.use('/api/assessments',  assessmentRoutes);
app.use('/api/criteria',     criterionRoutes);
app.use('/api/reports',      reportRoutes);
app.use('/api/audit',        auditRoutes);

// ─── Health check ────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// ─── 404 ─────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ error: 'Endpoint tapılmadı.' });
});

// ─── Global error handler ────────────────────────────────
app.use(errorHandler);

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`✅  API server: http://localhost:${PORT}`);
});

module.exports = app;
