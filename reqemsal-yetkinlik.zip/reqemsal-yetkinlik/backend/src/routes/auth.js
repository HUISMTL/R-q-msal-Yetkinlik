// src/routes/auth.js
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const { PrismaClient } = require('@prisma/client');
const { authenticate } = require('../middleware/auth');

const router = express.Router();
const prisma = new PrismaClient();

const generateToken = (userId) =>
  jwt.sign({ userId }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '8h'
  });

// POST /api/auth/login
router.post('/login',
  [
    body('username').trim().notEmpty().withMessage('İstifadəçi adı tələb olunur.'),
    body('password').notEmpty().withMessage('Şifrə tələb olunur.')
  ],
  async (req, res, next) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { username, password } = req.body;

      const user = await prisma.user.findUnique({
        where: { username },
        include: { organization: { select: { id: true, name: true, shortName: true, group: true } } }
      });

      if (!user || !user.active) {
        return res.status(401).json({ error: 'İstifadəçi adı və ya şifrə yanlışdır.' });
      }

      const passwordMatch = await bcrypt.compare(password, user.passwordHash);
      if (!passwordMatch) {
        // Audit log
        await prisma.auditLog.create({
          data: {
            userId: user.id,
            action: 'LOGIN_FAILED',
            details: { username },
            ipAddress: req.ip
          }
        });
        return res.status(401).json({ error: 'İstifadəçi adı və ya şifrə yanlışdır.' });
      }

      // Last login yenilə
      await prisma.user.update({
        where: { id: user.id },
        data: { lastLoginAt: new Date() }
      });

      // Audit log
      await prisma.auditLog.create({
        data: {
          userId: user.id,
          action: 'LOGIN',
          ipAddress: req.ip,
          userAgent: req.headers['user-agent']
        }
      });

      const token = generateToken(user.id);

      res.json({
        token,
        user: {
          id:           user.id,
          username:     user.username,
          fullName:     user.fullName,
          role:         user.role,
          organization: user.organization
        }
      });
    } catch (err) {
      next(err);
    }
  }
);

// POST /api/auth/logout
router.post('/logout', authenticate, async (req, res, next) => {
  try {
    await prisma.auditLog.create({
      data: {
        userId: req.user.id,
        action: 'LOGOUT',
        ipAddress: req.ip
      }
    });
    res.json({ message: 'Uğurla çıxış edildi.' });
  } catch (err) {
    next(err);
  }
});

// GET /api/auth/me
router.get('/me', authenticate, async (req, res) => {
  const { passwordHash, ...user } = req.user;
  res.json(user);
});

module.exports = router;
