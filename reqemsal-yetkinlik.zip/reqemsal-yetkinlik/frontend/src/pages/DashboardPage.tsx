// src/pages/DashboardPage.tsx
import { useQuery } from '@tanstack/react-query';
import { reportsApi } from '../api/services';

const H_COLORS: Record<number, { bg: string; color: string }> = {
  0: { bg: '#fee2e2', color: '#991b1b' },
  1: { bg: '#fed7aa', color: '#92400e' },
  2: { bg: '#fef9c3', color: '#713f12' },
  3: { bg: '#d1fae5', color: '#065f46' },
  4: { bg: '#6ee7b7', color: '#064e3b' },
  5: { bg: '#059669', color: '#fff' },
};

export default function DashboardPage() {
  const { data: summary, isLoading } = useQuery({
    queryKey: ['reports-summary'],
    queryFn: () => reportsApi.summary(2026).then(r => r.data)
  });
  const { data: heatmap } = useQuery({
    queryKey: ['reports-heatmap'],
    queryFn: () => reportsApi.heatmap(2026).then(r => r.data)
  });

  if (isLoading) return <Spinner />;

  return (
    <div style={{ padding: '1.75rem', background: '#f0f4fa', minHeight: 'calc(100vh - 56px)' }}>
      <div style={{ marginBottom: '1.5rem' }}>
        <div style={{ fontSize: 20, fontWeight: 700, letterSpacing: '-.03em', color: '#0f1117' }}>Rəqəmsal Yetkinlik Dashbordu</div>
        <div style={{ fontSize: 12, color: '#6b7280', marginTop: 3 }}>Azərbaycan Dövlət Qurumları · 2026 · {summary?.total ?? 0} qurum</div>
      </div>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: '1.75rem' }}>
        <StatCard label="Ölkə Orta Balı" value={summary?.countryAverage?.toFixed(2) ?? '—'} sub="5.00 üzərindən" primary />
        <StatCard label="Ümumi Qurum" value={summary?.total ?? '—'} sub="4 qrup üzrə" />
        <StatCard label="Ən Yüksək" value={summary?.ranking?.[0]?.score?.toFixed(2) ?? '—'} sub={summary?.ranking?.[0]?.orgName} green />
        <StatCard label="Ən Aşağı" value={summary?.ranking?.at(-1)?.score?.toFixed(2) ?? '—'} sub={summary?.ranking?.at(-1)?.orgName} red />
      </div>

      {/* Heat map */}
      {heatmap && (
        <div style={{ background: '#fff', border: '1px solid #e5e7eb', borderRadius: 12, overflow: 'hidden', marginBottom: 16 }}>
          <div style={{ padding: '.9rem 1.25rem', borderBottom: '1px solid #e5e7eb', display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontSize: 13, fontWeight: 600, flex: 1 }}>Heat Map — Kriteriya × Qurum</span>
            <span style={{ fontSize: 10, color: '#6b7280' }}>0–1 Kritik · 2–3 İnkişaf · 4–5 Yüksək</span>
          </div>
          <div style={{ overflowX: 'auto', padding: '1rem' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 11 }}>
              <thead>
                <tr>
                  <th style={{ padding: '5px 6px', color: '#9ca3af', fontWeight: 700, fontSize: 9, letterSpacing: '.07em', textTransform: 'uppercase', textAlign: 'left', minWidth: 150 }}>Qurum</th>
                  {heatmap.criteria.map((c: any) => (
                    <th key={c.code} style={{ padding: '5px 6px', color: '#9ca3af', fontWeight: 700, fontSize: 9, textTransform: 'uppercase', textAlign: 'center', whiteSpace: 'nowrap' }}>{c.code}</th>
                  ))}
                  <th style={{ padding: '5px 6px', color: '#9ca3af', fontWeight: 700, fontSize: 9, textTransform: 'uppercase', textAlign: 'center' }}>Ümumi</th>
                </tr>
              </thead>
              <tbody>
                {heatmap.heatmap.map((row: any, i: number) => (
                  <tr key={i}>
                    <td style={{ padding: '4px 6px', fontSize: 11, color: '#374151', fontWeight: 500 }}>{row.orgName}</td>
                    {heatmap.criteria.map((c: any) => {
                      const v = row.scores[c.code];
                      const h = v !== null && v !== undefined ? H_COLORS[Math.round(v)] : null;
                      return (
                        <td key={c.code} style={{ padding: '4px 6px', textAlign: 'center', fontFamily: 'JetBrains Mono, monospace', fontWeight: 600, fontSize: 11, borderRadius: 4, background: h?.bg || '#f3f4f6', color: h?.color || '#9ca3af' }}>
                          {v ?? 'N/A'}
                        </td>
                      );
                    })}
                    <td style={{ padding: '4px 6px', textAlign: 'center', fontFamily: 'JetBrains Mono, monospace', fontWeight: 700, fontSize: 12, background: H_COLORS[Math.round(row.total)]?.bg || '#f3f4f6', color: H_COLORS[Math.round(row.total)]?.color || '#6b7280', borderRadius: 4 }}>
                      {row.total?.toFixed(2)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Kriteriya orta balları */}
      {summary?.criterionAverages && (
        <div style={{ background: '#fff', border: '1px solid #e5e7eb', borderRadius: 12, overflow: 'hidden' }}>
          <div style={{ padding: '.9rem 1.25rem', borderBottom: '1px solid #e5e7eb' }}>
            <span style={{ fontSize: 13, fontWeight: 600 }}>Kriteriya üzrə Ölkə Ortası</span>
          </div>
          <div style={{ padding: '1.25rem', display: 'flex', flexDirection: 'column', gap: 10 }}>
            {[...summary.criterionAverages].sort((a: any, b: any) => b.average - a.average).map((c: any) => (
              <div key={c.code}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginBottom: 4 }}>
                  <span style={{ color: '#6b7280' }}>{c.code} · {c.name}</span>
                  <span style={{ fontFamily: 'JetBrains Mono, monospace', fontWeight: 600, color: c.average >= 3.5 ? '#047857' : c.average >= 2.5 ? '#1a4fa0' : c.average >= 1.5 ? '#b45309' : '#b91c1c' }}>
                    {c.average.toFixed(2)}
                  </span>
                </div>
                <div style={{ height: 5, background: '#e5e7eb', borderRadius: 3, overflow: 'hidden' }}>
                  <div style={{ height: '100%', borderRadius: 3, background: c.average >= 3.5 ? '#10b981' : c.average >= 2.5 ? '#1e63c8' : '#f59e0b', width: `${(c.average / 5) * 100}%`, transition: 'width .3s' }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Shared sub-components ────────────────────────────────
function StatCard({ label, value, sub, primary, green, red }: any) {
  return (
    <div style={{ background: primary ? '#103570' : '#fff', border: `1px solid ${primary ? '#1a4fa0' : '#e5e7eb'}`, borderRadius: 12, padding: '1.1rem 1.25rem', boxShadow: '0 1px 3px rgba(10,22,40,.06)' }}>
      <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: '.08em', textTransform: 'uppercase', color: primary ? 'rgba(255,255,255,.6)' : '#6b7280', marginBottom: '.4rem' }}>{label}</div>
      <div style={{ fontSize: 26, fontWeight: 700, letterSpacing: '-.04em', lineHeight: 1, color: primary ? '#fff' : green ? '#047857' : red ? '#b91c1c' : '#0f1117' }}>{value}</div>
      {sub && <div style={{ fontSize: 11, color: primary ? 'rgba(255,255,255,.5)' : '#9ca3af', marginTop: 3 }}>{sub}</div>}
    </div>
  );
}

function Spinner() {
  return <div style={{ padding: '3rem', textAlign: 'center', color: '#6b7280' }}>Yüklənir...</div>;
}
