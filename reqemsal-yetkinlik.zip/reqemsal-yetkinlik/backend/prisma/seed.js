// prisma/seed.js
const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');
const prisma = new PrismaClient();

async function main() {
  console.log('🌱  Seed başladı...');

  // ─── 1. QURUMLar ──────────────────────────────────────
  const orgs = await Promise.all([
    // Mərkəzi İcra Hakimiyyəti
    { name: 'ASAN Xidmət Dövlət Agentliyi', shortName: 'ASAN', group: 'MERKEZI_ICRA' },
    { name: 'Dövlət Miqrasiya Xidməti', shortName: 'DMX', group: 'MERKEZI_ICRA' },
    { name: 'Dövlət Vergi Xidməti', shortName: 'DVX', group: 'MERKEZI_ICRA' },
    { name: 'Elm və Təhsil Nazirliyi', shortName: 'ETN', group: 'MERKEZI_ICRA' },
    { name: 'Əmək və Əhalinin Sosial Müdafiəsi Nazirliyi', shortName: 'ƏƏSMN', group: 'MERKEZI_ICRA' },
    { name: 'Ədliyyə Nazirliyi', shortName: 'ƏN', group: 'MERKEZI_ICRA' },
    { name: 'Daxili İşlər Nazirliyi', shortName: 'DİN', group: 'MERKEZI_ICRA' },
    { name: 'Rəqəmsal İnkişaf və Nəqliyyat Nazirliyi', shortName: 'RİNN', group: 'MERKEZI_ICRA' },
    // Publik Hüquqi Şəxslər
    { name: 'Dövlət Sosial Müdafiə Fondu', shortName: 'DSMF', group: 'PUBLIK_HUQUQI' },
    { name: 'Tibbi Ərazi Bölmələrinin İdarəetməsi (TƏBIB)', shortName: 'TƏBIB', group: 'PUBLIK_HUQUQI' },
    { name: 'Dövlət Gömrük Komitəsi', shortName: 'DGK', group: 'PUBLIK_HUQUQI' },
    { name: 'Dövlət Əmlak Xidməti', shortName: 'DƏX', group: 'PUBLIK_HUQUQI' },
    { name: 'Dövlət Torpaq və Xəritəçəkmə Komitəsi', shortName: 'DTXK', group: 'PUBLIK_HUQUQI' },
    // Digər Dövlət Qurumları
    { name: 'Azərbaycan Respublikası Mərkəzi Bankı', shortName: 'MB', group: 'DIGER_DOVLET' },
    { name: 'Dövlət Statistika Komitəsi', shortName: 'DSK', group: 'DIGER_DOVLET' },
    { name: 'İqtisadiyyat Nazirliyi', shortName: 'İN', group: 'DIGER_DOVLET' },
    // Dövlət Mülkiyyətli Şirkətlər
    { name: '"Azərenerji" ASC', shortName: 'Azərenerji', group: 'DOVLET_MULKIYYETLI' },
    { name: '"Azərişıq" ASC', shortName: 'Azərişıq', group: 'DOVLET_MULKIYYETLI' },
    { name: '"Azəristiliktəchizat" ASC', shortName: 'Azəristiliktəchizat', group: 'DOVLET_MULKIYYETLI' },
    { name: '"Azərtelecom" MMC', shortName: 'Azərtelecom', group: 'DOVLET_MULKIYYETLI' },
    { name: 'AZƏRSU ASC', shortName: 'AZƏRSU', group: 'DOVLET_MULKIYYETLI' },
    { name: 'Azərbaycan Dövlət Dəmir Yolları (ADY)', shortName: 'ADY', group: 'DOVLET_MULKIYYETLI' }
  ].map(o =>
    prisma.organization.upsert({
      where: { name: o.name },
      update: {},
      create: o
    })
  ));
  console.log(`✅  ${orgs.length} qurum yaradıldı.`);

  // ─── 2. KRİTERİYALAR ──────────────────────────────────
  const criteriaData = [
    { code: 'D1', name: 'Governance (Leadership)', nameAz: 'İdarəetmə (Rəhbərlik)', weight: 0.09, orderIndex: 1 },
    { code: 'D2', name: 'Strategy', nameAz: 'Strategiya', weight: 0.10, orderIndex: 2 },
    { code: 'D3', name: 'Budget Allocation', nameAz: 'Büdcə Ayrılması', weight: 0.07, orderIndex: 3 },
    { code: 'D4', name: 'User-Oriented Services', nameAz: 'İstifadəçi Yönümlü Xidmətlər', weight: 0.13, orderIndex: 4 },
    { code: 'D5', name: 'Data Culture', nameAz: 'Məlumat Mədəniyyəti', weight: 0.08, orderIndex: 5 },
    { code: 'D6', name: 'G-Cloud Integration', nameAz: 'G-Cloud İnteqrasiyası', weight: 0.05, orderIndex: 6 },
    { code: 'D7', name: 'EHIS Integration', nameAz: 'EHİS İnteqrasiyası', weight: 0.05, orderIndex: 7 },
    { code: 'D8', name: 'Infrastructure', nameAz: 'İnfrastruktur', weight: 0.08, orderIndex: 8 },
    { code: 'D9', name: 'Artificial Intelligence', nameAz: 'Süni İntellekt', weight: 0.09, orderIndex: 9 },
    { code: 'D10', name: 'Digital Team', nameAz: 'Rəqəmsal Komanda', weight: 0.09, orderIndex: 10 },
    { code: 'D11', name: 'Internal Process Digitalization', nameAz: 'Daxili Proseslərin Rəqəmsallaşması', weight: 0.09, orderIndex: 11 },
    { code: 'D12', name: 'Security & Compliance', nameAz: 'Təhlükəsizlik və Uyğunluq', weight: 0.08, orderIndex: 12 }
  ];

  const criteria = [];
  for (const c of criteriaData) {
    const crit = await prisma.criterion.upsert({
      where: { code: c.code },
      update: { weight: c.weight, nameAz: c.nameAz },
      create: c
    });
    criteria.push(crit);
  }
  console.log(`✅  ${criteria.length} kriteriya yaradıldı.`);

  // ─── 3. SUALLAR (D4 tam nümunə, qalanlar əsas suallar) ─
  // D4 üçün tam sual strukturu
  const d4 = criteria.find(c => c.code === 'D4');
  const d4Questions = [
    { code: 'S1', text: 'Qurumunuz vətəndaşlara, hüquqi şəxslərə və ya digər qurumlara birbaşa xidmət göstərirmi?', type: 'radio', orderIndex: 1, options: ['Bəli', 'Xeyr'] },
    { code: 'S2a', text: 'Göstərdiyiniz xidmətlərin neçə faizi dxr.az platformasında qeydə alınıb?', type: 'radio', orderIndex: 2, isConditional: true, conditionRule: JSON.stringify({ field: 'S1', value: 'Bəli' }), options: ['Heç biri (0%)', 'Az hissəsi (1–20%)', 'Yarısına qədər (20–60%)', 'Böyük hissəsi (60–85%)', 'Demək olar hamısı (85–100%)'] },
    { code: 'S2b_online', text: 'Onlayn (elektron) xidmət sayı', type: 'number', orderIndex: 3, isConditional: true, conditionRule: JSON.stringify({ field: 'S1', value: 'Bəli' }) },
    { code: 'S2b_fiziki', text: 'Fiziki xidmət sayı', type: 'number', orderIndex: 4, isConditional: true, conditionRule: JSON.stringify({ field: 'S1', value: 'Bəli' }) },
    { code: 'S3a_endtoend', text: 'Tam end-to-end xidmət faizi', type: 'number', orderIndex: 5, isConditional: true, conditionRule: JSON.stringify({ field: 'S2b_online', gt: 0 }) },
    { code: 'S3a_muraciət', text: 'Müraciət hissəsi rəqəmsal faizi', type: 'number', orderIndex: 6, isConditional: true, conditionRule: JSON.stringify({ field: 'S2b_online', gt: 0 }) },
    { code: 'S3a_informativ', text: 'Yalnız informativ faizi', type: 'number', orderIndex: 7, isConditional: true, conditionRule: JSON.stringify({ field: 'S2b_online', gt: 0 }) },
    { code: 'S3b_interaktiv', text: 'İnteraktiv xidmət sayı', type: 'number', orderIndex: 8, isConditional: true, conditionRule: JSON.stringify({ field: 'S2b_online', gt: 0 }) },
    { code: 'S3b_informativ', text: 'İnformativ xidmət sayı', type: 'number', orderIndex: 9, isConditional: true, conditionRule: JSON.stringify({ field: 'S2b_online', gt: 0 }) },
    { code: 'S3b_proaktiv', text: 'Proaktiv xidmət sayı', type: 'number', orderIndex: 10, isConditional: true, conditionRule: JSON.stringify({ field: 'S2b_online', gt: 0 }) },
    { code: 'S4_mygov_web_only', text: 'Yalnız MyGov veb-də olan xidmət sayı', type: 'number', orderIndex: 11, isConditional: true, conditionRule: JSON.stringify({ field: 'S2b_online', gt: 0 }) },
    { code: 'S4_mygov_both', text: 'Həm MyGov veb, həm MyGov mobil-də olan xidmət sayı', type: 'number', orderIndex: 12, isConditional: true, conditionRule: JSON.stringify({ field: 'S2b_online', gt: 0 }) },
    { code: 'S4_mygov_mobile_only', text: 'Yalnız MyGov mobil-də olan xidmət sayı', type: 'number', orderIndex: 13, isConditional: true, conditionRule: JSON.stringify({ field: 'S2b_online', gt: 0 }) },
    { code: 'S5', text: 'Xidmətlər müyəssərlik standartlarına uyğun qurulmuşdur?', type: 'radio', orderIndex: 14, isConditional: true, conditionRule: JSON.stringify({ field: 'S4_mygov_both', gt: 0 }), options: ['Bəli, tam uyğun', 'Qismən', 'Xeyr'] },
    { code: 'S6', text: 'İstifadəçilərə xidmət mərhələləri üzrə proaktiv bildiriş göndərilirmi?', type: 'multiselect', orderIndex: 15, isConditional: true, conditionRule: JSON.stringify({ field: 'S3a_endtoend', gt: 0 }), options: ['SMS', 'Email', 'MyGov kabineti bildirişi', 'Xeyr, bildiriş göndərilmir'] },
    { code: 'S7', text: 'Xidmətlər başqa dövlət platformalarında da göstərilirmi?', type: 'radio', orderIndex: 16, isConditional: true, conditionRule: JSON.stringify({ field: 'S2b_online', gt: 0 }), options: ['Bəli', 'Xeyr'] },
    { code: 'S8', text: 'Xidmətlər açıq API-lər vasitəsilə üçüncü tərəflərə inteqrasiya üçün açıqdırmı?', type: 'radio', orderIndex: 17, isConditional: true, conditionRule: JSON.stringify({ field: 'S3a_endtoend', gt: 0 }), options: ['Bəli, açıq API-lər mövcuddur', 'Bu sahədə işlər aparılmaqdadır', 'Hüquqi baxımdan uyğun deyil', 'Hüquqi baxımdan uyğundur, lakin texniki mövcud deyil'] }
  ];

  for (const q of d4Questions) {
    const { options, ...qData } = q;
    const question = await prisma.question.upsert({
      where: { id: `${d4.id}_${q.code}` },
      update: {},
      create: { ...qData, criterionId: d4.id, id: `${d4.id}_${q.code}` }
    });
    if (options) {
      for (let i = 0; i < options.length; i++) {
        await prisma.questionOption.upsert({
          where: { id: `${question.id}_opt${i}` },
          update: {},
          create: {
            id: `${question.id}_opt${i}`,
            questionId: question.id,
            text: options[i],
            value: options[i],
            orderIndex: i
          }
        });
      }
    }
  }
  console.log(`✅  D4 üçün ${d4Questions.length} sual yaradıldı.`);

  // ─── 4. İSTİFADƏÇİLƏR ─────────────────────────────────
  const adminPass = await bcrypt.hash(process.env.ADMIN_PASSWORD || 'Admin@2026!', 12);
  const testPass  = await bcrypt.hash('Test@2026!', 12);

  const dmxOrg = orgs.find(o => o?.name?.includes('Miqrasiya'));

  await prisma.user.upsert({
    where: { username: 'super.admin' },
    update: {},
    create: {
      username: 'super.admin',
      email: 'admin@idda.az',
      passwordHash: adminPass,
      fullName: 'Sistem Administratoru',
      role: 'SUPER_ADMIN'
    }
  });

  if (dmxOrg) {
    await prisma.user.upsert({
      where: { username: 'miqrasiya.user' },
      update: {},
      create: {
        username: 'miqrasiya.user',
        email: 'user@migration.gov.az',
        passwordHash: testPass,
        fullName: 'Dövlət Miqrasiya Xidməti İstifadəçisi',
        role: 'QURUM',
        organizationId: dmxOrg.id
      }
    });
  }

  await prisma.user.upsert({
    where: { username: 'ekspert.user' },
    update: {},
    create: {
      username: 'ekspert.user',
      email: 'ekspert@idda.az',
      passwordHash: testPass,
      fullName: 'Ekspert İstifadəçisi',
      role: 'EKSPERT'
    }
  });

  console.log('✅  İstifadəçilər yaradıldı.');
  console.log('');
  console.log('─────────────────────────────────────────');
  console.log('🔑  Giriş məlumatları:');
  console.log('   super.admin / Admin@2026!');
  console.log('   miqrasiya.user / Test@2026!');
  console.log('   ekspert.user / Test@2026!');
  console.log('─────────────────────────────────────────');
  console.log('🎉  Seed tamamlandı!');
}

main()
  .catch(e => { console.error(e); process.exit(1); })
  .finally(() => prisma.$disconnect());
