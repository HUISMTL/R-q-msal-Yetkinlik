// src/pages/ReviewPage.tsx
import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { assessmentsApi, type CriterionScore } from '../api/services';
import toast from 'react-hot-toast';

export default function ReviewPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [localScores, setLocalScores] = useState<Record<string, number>>({});

  const { data: assessment, isLoading } = useQuery({
    queryKey: ['assessment', id],
    queryFn: () => assessmentsApi.get(id!).then(r => r.data),
    enabled: !!id
  });

  const startReviewMut = useMutation({
    mutationFn: () => assessmentsApi.startReview(id!),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['assessment', id] })
  });

  const updateScoresMut = useMutation({
    mutationFn: (scores: { criterionId: string; adminScore: number }[]) =>
      assessmentsApi.updateScores(id!, scores),
    onSuccess: () => toast.success('Ballar saxlanıldı.')
  });

  const approveMut = useMutation({
    mutationFn: (note: string) => assessmentsApi.approve(id!, note),
    onSuccess: () => { toast.success('Assessment təsdiqləndi!'); navigate('/assessments'); }
  });

  const rejectMut = useMutation({
    mutationFn: (note: string) => assessmentsApi.reject(id!, note),
    onSuccess: () => { toast.success('Assessment rədd edildi.'); navigate('/assessments'); }
  });

  if (isLoading || !assessment) {
    return <div style={{ padding: '2rem', color: '#6b7280' }}>Yüklənir...</div>;
  }

  const getScore = (s: CriterionScore) =>
    localScores[s.criterionId] ?? s.adminScore ?? s.systemScore ?? 0;

  const handleScoreClick = (criterionId: string, val: number) => {
    setLocalScores(prev => ({ ...prev, [criterionId]: val }));
  };

  const handleSaveScores = () => {
    const toSave = Object.entries(localScores).map(([criterionId, adminScore]) => ({
      criterionId, adminScore
    }));
    if (toSave.length) updateScoresMut.mutate(toSave);
  };

  const totalScore = assessment.scores?.reduce((sum, s) => {
    const bal = getScore(s);
    return sum + bal * (s.criterion?.weight ?? 0);
  }, 0) ?? 0;

  const sorted = [...(assessment.scores ?? [])].sort(
    (a, b) => a.criterion.orderIndex - b.criterion.orderIndex
  );

  return (
    <div style={{ padding: '1.75rem', background: '#f0f4fa', minHeight: 'calc(100vh - 56px)' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: '1.5rem' }}>
        <button onClick={() => navigate('/assessments')}
          style={{ padding: '5px 12px', background: 'transparent', border: '1px solid #e5e7eb', borderRadius: 8, fontSize: 12, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit', color: '#4b5563' }}>
          ← Geri
        </button>
        <div>
          <div style={{ fontSize: 20, fontWeight: 700, letterSpacing: '-.03em', color: '#0f1117' }}>
            {assessment.organization.name} — Nəzərdən Keçirilir
          </div>
          <div style={{ fontSize: 12, color: '#6b7280', marginTop: 3 }}>
            Hər kriteriya üzrə balı yoxlayın, zəruri hallarda düzəliş edin
          </div>
        </div>
      </div>

      {/* Start review button */}
      {assessment.status === 'SUBMITTED' && (
        <button onClick={() => startReviewMut.mutate()}
          style={{ marginBottom: '1rem', padding: '8px 16px', background: '#0e7490', color: '#fff', border: 'none', borderRadius: 8, fontSize: 12, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit' }}>
          Nəzərdən keçirməyə başla
        </button>
      )}

      {/* Scores card */}
      <div style={{ background: '#fff', border: '1px solid #e5e7eb', borderRadius: 12, overflow: 'hidden', marginBottom: 16 }}>
        {/* Card header */}
        <div style={{ background: '#0d2044', padding: '1.5rem 1.75rem', display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', borderRadius: '12px 12px 0 0' }}>
          <div>
            <div style={{ fontSize: 16, fontWeight: 700, color: '#fff', letterSpacing: '-.02em' }}>
              {assessment.organization.name}
            </div>
            <div style={{ fontSize: 11, color: '#b8d4f8', marginTop: 3 }}>
              {assessment.organization.group} · Self-assessment · {assessment.year}
            </div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontSize: 36, fontWeight: 700, letterSpacing: '-.05em', color: '#fff' }}>
              {totalScore.toFixed(2)}
            </div>
            <div style={{ fontSize: 10, color: '#b8d4f8' }}>
              {Object.keys(localScores).length > 0 ? 'Düzəliş edilmiş bal' : 'Sistem balı'}
            </div>
          </div>
        </div>

        {/* Scores grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, padding: '1.25rem' }}>
          {sorted.map(s => {
            const cur = getScore(s);
            const changed = localScores[s.criterionId] !== undefined;
            return (
              <div key={s.id} style={{
                background: changed ? '#f0f6ff' : '#f9fafb',
                border: `1px solid ${changed ? '#b8d4f8' : '#e5e7eb'}`,
                borderRadius: 10, padding: '.9rem'
              }}>
                <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9, color: '#9ca3af', marginBottom: 3 }}>
                  {s.criterion.code} · {(s.criterion.weight * 100).toFixed(0)}%
                  {changed && <span style={{ color: '#b45309', marginLeft: 6 }}>Düzəliş</span>}
                </div>
                <div style={{ fontSize: 11, fontWeight: 600, color: '#1e2433', marginBottom: 8 }}>
                  {s.criterion.nameAz}
                </div>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, marginBottom: 7 }}>
                  <span style={{ fontSize: 22, fontWeight: 700, color: changed ? '#1a4fa0' : '#0f1117', letterSpacing: '-.03em' }}>{cur}</span>
                  <span style={{ fontSize: 11, color: '#9ca3af' }}>/5</span>
                  <div style={{ flex: 1, height: 4, background: '#e5e7eb', borderRadius: 2, overflow: 'hidden', marginLeft: 8 }}>
                    <div style={{ height: '100%', background: cur >= 4 ? '#10b981' : cur >= 2.5 ? '#1e63c8' : '#f59e0b', borderRadius: 2, width: `${(cur / 5) * 100}%`, transition: 'width .2s' }} />
                  </div>
                </div>
                {/* Score buttons */}
                <div style={{ display: 'flex', gap: 3 }}>
                  {[0, 1, 2, 3, 4, 5].map(n => (
                    <button key={n}
                      onClick={() => handleScoreClick(s.criterionId, n)}
                      style={{
                        width: 26, height: 26, borderRadius: 5,
                        border: `1px solid ${cur === n ? '#1a4fa0' : '#e5e7eb'}`,
                        background: cur === n ? '#1a4fa0' : '#fff',
                        color: cur === n ? '#fff' : '#4b5563',
                        fontFamily: 'JetBrains Mono, monospace', fontSize: 11, fontWeight: 600,
                        cursor: 'pointer', transition: 'all .12s'
                      }}>
                      {n}
                    </button>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div style={{ padding: '1rem 1.25rem', borderTop: '1px solid #e5e7eb', display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ flex: 1, fontSize: 12, color: '#6b7280' }}>
            {Object.keys(localScores).length > 0
              ? <span>Düzəliş edildi · Yeni ümumi bal: <strong style={{ color: '#1a4fa0' }}>{totalScore.toFixed(2)}</strong></span>
              : <span>Bal düzəlişi etmək üçün 0–5 düymələrindən istifadə edin</span>
            }
          </div>
          {Object.keys(localScores).length > 0 && (
            <button onClick={handleSaveScores} disabled={updateScoresMut.isPending}
              style={{ padding: '7px 14px', background: '#0e7490', color: '#fff', border: 'none', borderRadius: 8, fontSize: 12, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit' }}>
              {updateScoresMut.isPending ? 'Saxlanılır...' : 'Balları Saxla'}
            </button>
          )}
          <button onClick={() => navigate('/assessments')}
            style={{ padding: '7px 14px', background: 'transparent', border: '1px solid #e5e7eb', borderRadius: 8, fontSize: 12, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit', color: '#4b5563' }}>
            Ləğv et
          </button>
          <button
            onClick={() => { const n = window.prompt('Rədd səbəbini yazın:'); if (n) rejectMut.mutate(n); }}
            disabled={rejectMut.isPending}
            style={{ padding: '7px 14px', background: '#b91c1c', color: '#fff', border: 'none', borderRadius: 8, fontSize: 12, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit' }}>
            ✕ Rədd et
          </button>
          <button
            onClick={() => { const n = window.prompt('Admin qeydi (ixtiyari):') || ''; approveMut.mutate(n); }}
            disabled={approveMut.isPending}
            style={{ padding: '7px 18px', background: '#047857', color: '#fff', border: 'none', borderRadius: 8, fontSize: 12, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit' }}>
            ✓ Təsdiqlə və Hesabat Göndər
          </button>
        </div>
      </div>
    </div>
  );
}
