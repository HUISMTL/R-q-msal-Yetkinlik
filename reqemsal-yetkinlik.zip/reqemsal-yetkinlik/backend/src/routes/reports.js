// src/routes/reports.js
const express = require('express');
const { PrismaClient } = require('@prisma/client');
const { authenticate, isAnalyst } = require('../middleware/auth');

const router = express.Router();
const prisma = new PrismaClient();

// GET /api/reports/summary — Ölkə üzrə xülasə
router.get('/summary', authenticate, isAnalyst, async (req, res, next) => {
  try {
    const { year = 2026 } = req.query;

    const assessments = await prisma.assessment.findMany({
      where: { year: parseInt(year), status: 'APPROVED' },
      include: {
        organization: { select: { name: true, group: true } },
        scores: { include: { criterion: true } }
      }
    });

    if (!assessments.length) return res.json({ total: 0, averages: [], orgGroups: [] });

    const criteria = await prisma.criterion.findMany({ orderBy: { orderIndex: 'asc' } });

    // Hər kriteriya üçün orta bal
    const criterionAverages = criteria.map(c => {
      const vals = assessments
        .flatMap(a => a.scores)
        .filter(s => s.criterionId === c.id && !s.isNA)
        .map(s => s.adminScore ?? s.systemScore ?? 0);

      return {
        criterionId: c.id,
        code: c.code,
        name: c.nameAz,
        weight: c.weight,
        average: vals.length
          ? Math.round((vals.reduce((a, b) => a + b, 0) / vals.length) * 100) / 100
          : 0,
        count: vals.length
      };
    });

    // Ölkə orta balı (çəkili)
    const countryAvg = criterionAverages.reduce((sum, c) => sum + c.average * c.weight, 0);

    // Qrup üzrə
    const groups = ['MERKEZI_ICRA', 'PUBLIK_HUQUQI', 'DOVLET_MULKIYYETLI', 'DIGER_DOVLET'];
    const orgGroups = groups.map(group => {
      const groupAssessments = assessments.filter(a => a.organization.group === group);
      if (!groupAssessments.length) return { group, average: 0, count: 0 };
      const scores = groupAssessments.map(a => computeWeightedScore(a.scores));
      const avg = scores.reduce((a, b) => a + b, 0) / scores.length;
      return { group, average: Math.round(avg * 100) / 100, count: groupAssessments.length };
    });

    // Org sıralaması
    const ranking = assessments.map(a => ({
      orgName: a.organization.name,
      group: a.organization.group,
      score: computeWeightedScore(a.scores)
    })).sort((a, b) => b.score - a.score);

    res.json({
      year: parseInt(year),
      total: assessments.length,
      countryAverage: Math.round(countryAvg * 100) / 100,
      criterionAverages,
      orgGroups,
      ranking
    });
  } catch (err) { next(err); }
});

// GET /api/reports/heatmap — Heat map data
router.get('/heatmap', authenticate, isAnalyst, async (req, res, next) => {
  try {
    const { year = 2026 } = req.query;

    const assessments = await prisma.assessment.findMany({
      where: { year: parseInt(year), status: 'APPROVED' },
      include: {
        organization: { select: { name: true, shortName: true, group: true } },
        scores: {
          include: { criterion: { select: { code: true, nameAz: true, orderIndex: true } } },
          orderBy: { criterion: { orderIndex: 'asc' } }
        }
      }
    });

    const criteria = await prisma.criterion.findMany({
      orderBy: { orderIndex: 'asc' },
      select: { code: true, nameAz: true, orderIndex: true }
    });

    const heatmap = assessments.map(a => ({
      orgName: a.organization.name,
      group:   a.organization.group,
      total:   computeWeightedScore(a.scores),
      scores:  a.scores.reduce((acc, s) => {
        acc[s.criterion.code] = s.adminScore ?? s.systemScore ?? null;
        return acc;
      }, {})
    }));

    res.json({ criteria, heatmap });
  } catch (err) { next(err); }
});

function computeWeightedScore(scores) {
  if (!scores?.length) return 0;
  return Math.round(
    scores.reduce((sum, s) => sum + ((s.adminScore ?? s.systemScore ?? 0) * (s.criterion?.weight ?? 0)), 0) * 100
  ) / 100;
}

module.exports = router;
