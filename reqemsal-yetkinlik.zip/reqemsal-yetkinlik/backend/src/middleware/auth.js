// src/middleware/auth.js
const jwt = require('jsonwebtoken');
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const authenticate = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Token təqdim edilməyib.' });
    }

    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    const user = await prisma.user.findUnique({
      where: { id: decoded.userId },
      include: { organization: true }
    });

    if (!user || !user.active) {
      return res.status(401).json({ error: 'İstifadəçi tapılmadı və ya deaktivdir.' });
    }

    req.user = user;
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Token müddəti bitib.' });
    }
    return res.status(401).json({ error: 'Keçərsiz token.' });
  }
};

// Rol yoxlaması — bir və ya bir neçə rol qəbul edir
const authorize = (...roles) => (req, res, next) => {
  if (!roles.includes(req.user.role)) {
    return res.status(403).json({ error: 'Bu əməliyyat üçün icazəniz yoxdur.' });
  }
  next();
};

// Admin rolları
const isAdmin = authorize('SUPER_ADMIN', 'ADMIN');
const isReviewer = authorize('SUPER_ADMIN', 'ADMIN', 'QIYMETLENDIRICI');
const isAnalyst = authorize('SUPER_ADMIN', 'ADMIN', 'EKSPERT', 'QIYMETLENDIRICI');

// Qurum öz assessmentinə çıxışı yoxlayır
const ownsAssessment = async (req, res, next) => {
  try {
    if (['SUPER_ADMIN', 'ADMIN', 'QIYMETLENDIRICI', 'EKSPERT'].includes(req.user.role)) {
      return next();
    }
    const assessment = await prisma.assessment.findUnique({
      where: { id: req.params.id }
    });
    if (!assessment) return res.status(404).json({ error: 'Assessment tapılmadı.' });
    if (assessment.organizationId !== req.user.organizationId) {
      return res.status(403).json({ error: 'Bu assessmentə çıxış icazəniz yoxdur.' });
    }
    req.assessment = assessment;
    next();
  } catch (err) {
    next(err);
  }
};

module.exports = { authenticate, authorize, isAdmin, isReviewer, isAnalyst, ownsAssessment };
