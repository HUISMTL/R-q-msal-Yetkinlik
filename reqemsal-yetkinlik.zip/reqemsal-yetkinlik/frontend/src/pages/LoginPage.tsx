// src/pages/LoginPage.tsx
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth, isQurum } from '../hooks/useAuth';
import toast from 'react-hot-toast';

export default function LoginPage() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const { login, isLoading, user } = useAuth();
  const navigate = useNavigate();

  // Artıq daxil olubsa yönləndir
  if (user) {
    navigate(isQurum(user) ? '/qurumum' : '/', { replace: true });
    return null;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await login(username, password);
      const u = useAuth.getState().user;
      toast.success(`Xoş gəldiniz, ${u?.fullName}!`);
      navigate(isQurum(u) ? '/qurumum' : '/', { replace: true });
    } catch (err: any) {
      toast.error(err?.response?.data?.error || 'Giriş uğursuz oldu.');
    }
  };

  return (
    <div style={{
      minHeight: '100vh', display: 'flex',
      background: 'linear-gradient(160deg, #0a1628 0%, #0d2044 40%, #103570 100%)',
      position: 'relative', overflow: 'hidden'
    }}>
      {/* Sol tərəf */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '4rem 3rem 4rem 5rem' }}>
        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: 8,
          background: 'rgba(255,255,255,.1)', border: '1px solid rgba(255,255,255,.15)',
          borderRadius: 20, padding: '5px 14px', fontSize: 11, fontWeight: 600,
          color: '#deeafd', letterSpacing: '.06em', textTransform: 'uppercase', marginBottom: '2rem'
        }}>İDDA · 2026</div>

        <h1 style={{ fontSize: 36, fontWeight: 700, color: '#fff', letterSpacing: '-.03em', lineHeight: 1.15, marginBottom: '1rem' }}>
          Rəqəmsal<br />
          <span style={{ color: '#6da3ee' }}>Yetkinlik</span><br />
          Platforması
        </h1>

        <p style={{ fontSize: 13, color: '#b8d4f8', lineHeight: 1.7, maxWidth: 380 }}>
          Dövlət qurumlarının rəqəmsallaşma səviyyəsinin qiymətləndirilməsi üçün vahid platforma.
          İstifadəçi hüquqları admin tərəfindən müəyyən edilir.
        </p>
      </div>

      {/* Sağ tərəf — Login formu */}
      <div style={{ width: 420, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '3rem 3rem 3rem 1.5rem' }}>
        <div style={{
          background: '#fff', borderRadius: 16,
          boxShadow: '0 20px 60px rgba(10,22,40,.4)',
          padding: '2.25rem', width: '100%',
          animation: 'fadeUp .4s ease'
        }}>
          <style>{`@keyframes fadeUp { from { opacity:0; transform:translateY(12px) } to { opacity:1; transform:none } }`}</style>

          <h2 style={{ fontSize: 17, fontWeight: 700, color: '#0f1117', marginBottom: 3, letterSpacing: '-.02em' }}>
            Sistemə daxil ol
          </h2>
          <p style={{ fontSize: 12, color: '#6b7280', marginBottom: '1.5rem' }}>
            Sizə verilmiş istifadəçi adı və şifrədən istifadə edin.
          </p>

          <form onSubmit={handleSubmit}>
            <div style={{ marginBottom: '1rem' }}>
              <label style={{ display: 'block', fontSize: 11, fontWeight: 600, color: '#374151', marginBottom: 5, letterSpacing: '.02em' }}>
                İstifadəçi adı
              </label>
              <input
                value={username} onChange={e => setUsername(e.target.value)}
                placeholder="istifadeci.adi" required autoFocus
                style={{
                  width: '100%', padding: '10px 12px',
                  border: '1.5px solid #e5e7eb', borderRadius: 8,
                  fontFamily: 'inherit', fontSize: 13, color: '#0f1117',
                  background: '#f9fafb', outline: 'none', transition: 'all .15s'
                }}
                onFocus={e => { e.target.style.borderColor = '#1e63c8'; e.target.style.boxShadow = '0 0 0 3px #deeafd'; }}
                onBlur={e => { e.target.style.borderColor = '#e5e7eb'; e.target.style.boxShadow = 'none'; }}
              />
            </div>

            <div style={{ marginBottom: '1.5rem' }}>
              <label style={{ display: 'block', fontSize: 11, fontWeight: 600, color: '#374151', marginBottom: 5, letterSpacing: '.02em' }}>
                Şifrə
              </label>
              <input
                type="password" value={password} onChange={e => setPassword(e.target.value)}
                placeholder="••••••••" required
                style={{
                  width: '100%', padding: '10px 12px',
                  border: '1.5px solid #e5e7eb', borderRadius: 8,
                  fontFamily: 'inherit', fontSize: 13, color: '#0f1117',
                  background: '#f9fafb', outline: 'none', transition: 'all .15s'
                }}
                onFocus={e => { e.target.style.borderColor = '#1e63c8'; e.target.style.boxShadow = '0 0 0 3px #deeafd'; }}
                onBlur={e => { e.target.style.borderColor = '#e5e7eb'; e.target.style.boxShadow = 'none'; }}
              />
            </div>

            <button
              type="submit" disabled={isLoading}
              style={{
                width: '100%', padding: 12,
                background: isLoading ? '#6da3ee' : '#1a4fa0',
                color: '#fff', border: 'none', borderRadius: 8,
                fontFamily: 'inherit', fontSize: 14, fontWeight: 600,
                cursor: isLoading ? 'not-allowed' : 'pointer', transition: 'all .15s'
              }}
            >
              {isLoading ? 'Yüklənir...' : 'Daxil ol'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
