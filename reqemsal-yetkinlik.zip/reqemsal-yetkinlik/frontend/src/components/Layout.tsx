// src/components/Layout.tsx
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuth, isAdmin, isAnalyst, isQurum, isReviewer } from '../hooks/useAuth';
import toast from 'react-hot-toast';

// ─── Nav item type ────────────────────────────────────────
interface NavItem { to: string; label: string; icon: React.ReactNode; badge?: number }

const ChartIcon = () => <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>;
const ClipboardIcon = () => <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"/></svg>;
const ReportIcon = () => <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>;
const UsersIcon = () => <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"/></svg>;
const ListIcon = () => <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 10h16M4 14h16M4 18h16"/></svg>;
const BuildingIcon = () => <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/></svg>;
const EditIcon = () => <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>;
const LogoutIcon = () => <svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>;

export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    toast.success('Sistemdən çıxış edildi.');
    navigate('/login');
  };

  // ─── Rola görə nav itemlər ────────────────────────────
  const navItems: NavItem[] = [];

  if (isAnalyst(user)) {
    navItems.push({ to: '/', label: 'Dashboard', icon: <ChartIcon /> });
  }
  if (isReviewer(user)) {
    navItems.push({ to: '/assessments', label: 'Qiymətləndirmələr', icon: <ClipboardIcon /> });
  }
  if (isAnalyst(user)) {
    navItems.push({ to: '/reports', label: 'Hesabatlar', icon: <ReportIcon /> });
  }
  if (isAdmin(user)) {
    navItems.push({ to: '/users', label: 'İstifadəçilər', icon: <UsersIcon /> });
    navItems.push({ to: '/audit', label: 'Audit Log', icon: <ListIcon /> });
  }
  if (isQurum(user)) {
    navItems.push({ to: '/qurumum', label: 'Qurumum', icon: <BuildingIcon /> });
    navItems.push({ to: '/assessment', label: 'Self-Assessment', icon: <EditIcon /> });
  }

  const initials = user?.fullName?.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase() || '??';

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      {/* ── TOPBAR ── */}
      <header style={{
        background: '#0d2044', height: 56, display: 'flex', alignItems: 'center',
        padding: '0 1.5rem', gap: 0, position: 'sticky', top: 0, zIndex: 200,
        boxShadow: '0 2px 12px rgba(10,22,40,.3)', flexShrink: 0
      }}>
        {/* Logo */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginRight: '2rem' }}>
          <div style={{ width: 34, height: 34, borderRadius: 8, background: '#1e63c8', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <ChartIcon />
          </div>
          <div>
            <div style={{ fontSize: 14, fontWeight: 700, color: '#fff', letterSpacing: '-.01em' }}>Rəqəmsal Yetkinlik</div>
            <div style={{ fontSize: 10, color: '#b8d4f8', letterSpacing: '.04em' }}>İDDA · 2026</div>
          </div>
        </div>

        {/* Nav */}
        <nav style={{ display: 'flex', gap: 2 }}>
          {navItems.map(item => (
            <NavLink key={item.to} to={item.to} end={item.to === '/' || item.to === '/qurumum'}
              style={({ isActive }) => ({
                display: 'flex', alignItems: 'center', gap: 6,
                padding: '7px 12px', borderRadius: 6,
                fontSize: 12, fontWeight: 500, textDecoration: 'none', whiteSpace: 'nowrap',
                color: isActive ? '#fff' : '#b8d4f8',
                background: isActive ? 'rgba(255,255,255,.15)' : 'transparent',
                transition: 'all .15s'
              })}>
              {item.icon}{item.label}
              {item.badge ? (
                <span style={{ background: '#b91c1c', color: '#fff', fontSize: 10, fontWeight: 700, borderRadius: 10, padding: '1px 6px', marginLeft: 2 }}>
                  {item.badge}
                </span>
              ) : null}
            </NavLink>
          ))}
        </nav>

        <div style={{ flex: 1 }} />

        {/* User */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: '#fff' }}>{user?.fullName}</div>
            <div style={{ fontSize: 10, color: '#b8d4f8', textTransform: 'uppercase', letterSpacing: '.05em' }}>
              {ROLE_LABELS[user?.role || ''] || user?.role}
            </div>
          </div>
          <div style={{ width: 32, height: 32, borderRadius: '50%', background: '#1e63c8', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 700 }}>
            {initials}
          </div>
          <button onClick={handleLogout} style={{
            display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: '#6da3ee',
            cursor: 'pointer', padding: '5px 8px', borderRadius: 6, transition: 'all .15s',
            border: 'none', background: 'transparent', fontFamily: 'inherit'
          }}>
            <LogoutIcon />Çıxış
          </button>
        </div>
      </header>

      {/* ── PAGE CONTENT ── */}
      <main style={{ flex: 1 }}>
        <Outlet />
      </main>
    </div>
  );
}

const ROLE_LABELS: Record<string, string> = {
  SUPER_ADMIN:     'Super Admin',
  ADMIN:           'Admin',
  EKSPERT:         'Ekspert',
  QIYMETLENDIRICI: 'Qiymətləndiricı',
  QURUM:           'Qurum İstifadəçisi'
};
