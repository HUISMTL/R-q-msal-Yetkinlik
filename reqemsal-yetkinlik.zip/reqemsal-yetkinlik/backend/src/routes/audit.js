// src/routes/audit.js
const express = require('express');
const { PrismaClient } = require('@prisma/client');
const { authenticate, isAdmin } = require('../middleware/auth');
const router = express.Router();
const prisma = new PrismaClient();

router.get('/', authenticate, isAdmin, async (req, res, next) => {
  try {
    const { limit = 50, action, userId } = req.query;
    const where = {};
    if (action) where.action = action;
    if (userId) where.userId = userId;

    const logs = await prisma.auditLog.findMany({
      where,
      include: {
        user: { select: { fullName: true, role: true } },
        assessment: { select: { organization: { select: { name: true } } } }
      },
      orderBy: { createdAt: 'desc' },
      take: parseInt(limit)
    });
    res.json(logs);
  } catch (err) { next(err); }
});

module.exports = router;
