// src/pages/AuditPage.tsx
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { auditApi, type AuditLog } from '../api/services';

const DOT_COLORS: Record<string, string> = {
  LOGIN:               '#10b981',
  LOGOUT:              '#9ca3af',
  LOGIN_FAILED:        '#ef4444',
  ASSESSMENT_CREATED:  '#1e63c8',
  ASSESSMENT_SUBMITTED:'#f59e0b',
  REVIEW_STARTED:      '#0e7490',
  SCORES_UPDATED:      '#1a4fa0',
  ASSESSMENT_APPROVED: '#047857',
  ASSESSMENT_REJECTED: '#b91c1c',
  USER_CREATED:        '#6b21a8',
  USER_UPDATED:        '#6b21a8',
  REPORT_SENT:         '#047857',
};

const ACTION_LABELS: Record<string, string> = {
  LOGIN:               'Sistemə giriş',
  LOGOUT:              'Sistemdən çıxış',
  LOGIN_FAILED:        'Uğursuz giriş cəhdi',
  ASSESSMENT_CREATED:  'Assessment yaradıldı',
  ASSESSMENT_SUBMITTED:'Assessment göndərildi',
  REVIEW_STARTED:      'Nəzərdən keçirilməyə başlandı',
  SCORES_UPDATED:      'Ballar dəyişdirildi',
  ASSESSMENT_APPROVED: 'Assessment təsdiqləndi',
  ASSESSMENT_REJECTED: 'Assessment rədd edildi',
  USER_CREATED:        'İstifadəçi yaradıldı',
  USER_UPDATED:        'İstifadəçi yeniləndi',
  REPORT_SENT:         'Hesabat göndərildi',
};

export default function AuditPage() {
  const [actionFilter, setActionFilter] = useState('');
  const [search, setSearch] = useState('');

  const { data: logs, isLoading } = useQuery({
    queryKey: ['audit', actionFilter],
    queryFn: () => auditApi.list({ limit: 200, action: actionFilter || undefined }).then(r => r.data)
  });

  const filtered = logs?.filter(l => {
    if (!search) return true;
    const text = `${l.user?.fullName} ${l.action} ${l.assessment?.organization?.name} ${l.ipAddress}`.toLowerCase();
    return text.includes(search.toLowerCase());
  }) ?? [];

  return (
    <div style={{ padding: '1.75rem', background: '#f0f4fa', minHeight: 'calc(100vh - 56px)' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '1.5rem' }}>
        <div>
          <div style={{ fontSize: 20, fontWeight: 700, letterSpacing: '-.03em', color: '#0f1117' }}>Audit Log</div>
          <div style={{ fontSize: 12, color: '#6b7280', marginTop: 3 }}>Platformada həyata keçirilən bütün əməliyyatların tam qeydi</div>
        </div>
        <button style={{ padding: '7px 14px', background: 'transparent', border: '1px solid #e5e7eb', borderRadius: 8, fontSize: 12, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit', color: '#4b5563', display: 'flex', alignItems: 'center', gap: 5 }}>
          <svg width="12" height="12" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
          CSV
        </button>
      </div>

      {/* Filters */}
      <div style={{ display: 'flex', gap: 8, marginBottom: '1.25rem' }}>
        <div style={{ position: 'relative', flex: 1 }}>
          <svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="#9ca3af" strokeWidth={2}
            style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)' }}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
          </svg>
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="İstifadəçi, hadisə, IP..." style={{ width: '100%', padding: '8px 12px 8px 32px', border: '1px solid #e5e7eb', borderRadius: 8, fontFamily: 'inherit', fontSize: 12, outline: 'none', background: '#fff' }} />
        </div>
        <select value={actionFilter} onChange={e => setActionFilter(e.target.value)}
          style={{ padding: '8px 12px', border: '1px solid #e5e7eb', borderRadius: 8, fontFamily: 'inherit', fontSize: 12, outline: 'none', background: '#fff' }}>
          <option value="">Bütün hadisələr</option>
          {Object.entries(ACTION_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </select>
      </div>

      {/* Log list */}
      <div style={{ background: '#fff', border: '1px solid #e5e7eb', borderRadius: 12, overflow: 'hidden' }}>
        {isLoading ? (
          <div style={{ padding: '2rem', textAlign: 'center', color: '#6b7280' }}>Yüklənir...</div>
        ) : filtered.length === 0 ? (
          <div style={{ padding: '2rem', textAlign: 'center', color: '#9ca3af' }}>Qeyd tapılmadı.</div>
        ) : (
          <div style={{ padding: '0 1.25rem' }}>
            {filtered.map((log: AuditLog) => (
              <div key={log.id} style={{ display: 'flex', alignItems: 'flex-start', gap: 10, padding: '10px 0', borderBottom: '1px solid #f3f4f6' }}>
                <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: '#9ca3af', whiteSpace: 'nowrap', marginTop: 1, minWidth: 80 }}>
                  {new Date(log.createdAt).toLocaleString('az-AZ', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                </div>
                <div style={{ width: 6, height: 6, borderRadius: '50%', background: DOT_COLORS[log.action] || '#9ca3af', flexShrink: 0, marginTop: 4 }} />
                <div style={{ flex: 1, fontSize: 12, color: '#4b5563', lineHeight: 1.5 }}>
                  <strong style={{ color: '#0f1117' }}>{log.user?.fullName || 'Sistem'}</strong>
                  {' → '}
                  <span style={{ color: DOT_COLORS[log.action] || '#6b7280' }}>{ACTION_LABELS[log.action] || log.action}</span>
                  {log.assessment?.organization?.name && (
                    <span style={{ color: '#6b7280' }}> · {log.assessment.organization.name}</span>
                  )}
                  {log.details && Object.keys(log.details).length > 0 && (
                    <span style={{ color: '#9ca3af', fontSize: 10, marginLeft: 6 }}>
                      {JSON.stringify(log.details).slice(0, 60)}...
                    </span>
                  )}
                </div>
                {log.ipAddress && (
                  <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: '#9ca3af', flexShrink: 0 }}>
                    {log.ipAddress}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
