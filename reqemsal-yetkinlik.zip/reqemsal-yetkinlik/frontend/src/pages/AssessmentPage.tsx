// src/pages/AssessmentPage.tsx
import { useState, useEffect, useCallback, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useMutation } from '@tanstack/react-query';
import { assessmentsApi, criteriaApi, type Answer, type Criterion } from '../api/services';
import { useAuth } from '../hooks/useAuth';
import toast from 'react-hot-toast';

// ─── Shared styles ────────────────────────────────────────
const S = {
  card: { background: '#fff', border: '1px solid #e5e7eb', borderRadius: 12, overflow: 'hidden', boxShadow: '0 1px 3px rgba(10,22,40,.06)' },
  label: { fontSize: 11, fontWeight: 700, letterSpacing: '.08em', textTransform: 'uppercase' as const, color: '#6b7280' },
  radioOpt: (selected: boolean) => ({
    display: 'flex', alignItems: 'center', gap: 9,
    padding: '9px 12px', border: `1.5px solid ${selected ? '#1a4fa0' : '#e5e7eb'}`,
    borderRadius: 8, cursor: 'pointer', fontSize: 12, color: selected ? '#0f1117' : '#4b5563',
    background: selected ? '#f0f6ff' : '#fff', transition: 'all .12s', marginBottom: 6
  }),
  numInput: {
    width: 70, padding: '6px 8px', textAlign: 'center' as const,
    border: '1.5px solid #e5e7eb', borderRadius: 6,
    fontFamily: 'JetBrains Mono, monospace', fontSize: 14, fontWeight: 600, color: '#0f1117', outline: 'none'
  }
};

export default function AssessmentPage() {
  const { id } = useParams<{ id?: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [assessmentId, setAssessmentId] = useState<string | null>(id || null);
  const [activeCritIdx, setActiveCritIdx] = useState(0);
  const [answers, setAnswers] = useState<Record<string, Answer>>({});
  const autoSaveTimer = useRef<ReturnType<typeof setTimeout>>();

  // ─── Kriteriyaları çək ──────────────────────────────────
  const { data: criteria } = useQuery({
    queryKey: ['criteria'],
    queryFn: () => criteriaApi.list().then(r => r.data)
  });

  // ─── Mövcud assessment yükle ────────────────────────────
  const { data: assessment } = useQuery({
    queryKey: ['assessment', assessmentId],
    queryFn: () => assessmentsApi.get(assessmentId!).then(r => r.data),
    enabled: !!assessmentId
  });

  // ─── Assessment yarat ───────────────────────────────────
  const createMutation = useMutation({
    mutationFn: () => assessmentsApi.create(),
    onSuccess: (r) => {
      setAssessmentId(r.data.id);
      navigate(`/assessment/${r.data.id}`, { replace: true });
    },
    onError: (err: any) => {
      const existId = err?.response?.data?.assessmentId;
      if (existId) {
        setAssessmentId(existId);
        navigate(`/assessment/${existId}`, { replace: true });
      } else {
        toast.error(err?.response?.data?.error || 'Xəta baş verdi.');
      }
    }
  });

  // ─── Cavabları saxla ─────────────────────────────────────
  const saveMutation = useMutation({
    mutationFn: (ans: Answer[]) => assessmentsApi.saveAnswers(assessmentId!, ans),
  });

  // ─── Submit ──────────────────────────────────────────────
  const submitMutation = useMutation({
    mutationFn: () => assessmentsApi.submit(assessmentId!),
    onSuccess: () => {
      toast.success('Assessment uğurla göndərildi!');
      navigate('/qurumum');
    },
    onError: (err: any) => toast.error(err?.response?.data?.error || 'Göndərmə uğursuz oldu.')
  });

  // Assessment yoxdursa yarat
  useEffect(() => {
    if (!assessmentId) createMutation.mutate();
  }, []);

  // Cavabları assessment-dən yüklə
  useEffect(() => {
    if (!assessment?.answers) return;
    const mapped: Record<string, Answer> = {};
    for (const a of assessment.answers) {
      mapped[a.questionId] = a;
    }
    setAnswers(mapped);
  }, [assessment]);

  // ─── Auto-save (debounce 3s) ─────────────────────────────
  const scheduleAutoSave = useCallback(() => {
    if (autoSaveTimer.current) clearTimeout(autoSaveTimer.current);
    autoSaveTimer.current = setTimeout(() => {
      const toSave = Object.values(answers);
      if (toSave.length && assessmentId) {
        saveMutation.mutate(toSave);
      }
    }, 3000);
  }, [answers, assessmentId]);

  const setAnswer = (questionId: string, partial: Partial<Answer>) => {
    setAnswers(prev => {
      const updated = { ...prev, [questionId]: { ...prev[questionId], questionId, ...partial } };
      return updated;
    });
    scheduleAutoSave();
  };

  const getVal = (qId: string) => answers[qId];

  if (!criteria) return <div style={{ padding: '2rem', color: '#6b7280' }}>Yüklənir...</div>;

  const activeCrit: Criterion = criteria[activeCritIdx];
  const completedCount = criteria.filter(c =>
    c.questions.filter(q => !q.isConditional).every(q => answers[q.id])
  ).length;

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '200px 1fr', gap: 20, padding: '1.75rem', minHeight: 'calc(100vh - 56px)', background: '#f0f4fa', alignItems: 'start' }}>
      {/* ── Kriteriya nav ── */}
      <nav style={{ ...S.card, padding: '.75rem', position: 'sticky', top: 76 }}>
        <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: '.1em', textTransform: 'uppercase', color: '#9ca3af', marginBottom: '.5rem', padding: '0 4px' }}>
          Kriteriyalar
        </div>
        {criteria.map((c, idx) => {
          const done = c.questions.filter(q => !q.isConditional).every(q => answers[q.id]);
          const active = idx === activeCritIdx;
          return (
            <div key={c.id} onClick={() => setActiveCritIdx(idx)}
              style={{
                display: 'flex', alignItems: 'center', gap: 7,
                padding: '7px 8px', borderRadius: 6, cursor: 'pointer',
                fontSize: 11, fontWeight: active ? 600 : 500,
                color: active ? '#1a4fa0' : done ? '#047857' : '#4b5563',
                background: active ? '#f0f6ff' : 'transparent',
                marginBottom: 1, transition: 'all .12s'
              }}>
              <div style={{ flex: 1 }}>{c.nameAz}</div>
              {done && (
                <div style={{ width: 14, height: 14, borderRadius: '50%', background: '#10b981', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <svg width="7" height="7" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3.5"><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7"/></svg>
                </div>
              )}
            </div>
          );
        })}
      </nav>

      {/* ── Form ── */}
      <div style={S.card}>
        {/* Header */}
        <div style={{ padding: '1.25rem 1.75rem', borderBottom: '1px solid #e5e7eb', background: 'linear-gradient(90deg,#f0f6ff,#fff)' }}>
          <div style={{ fontSize: 10, fontWeight: 600, background: '#1a4fa0', color: '#fff', borderRadius: 5, padding: '2px 8px', display: 'inline-block', marginBottom: 6 }}>
            Kriteriya {activeCritIdx + 1} / {criteria.length}
          </div>
          <div style={{ fontSize: 16, fontWeight: 700, letterSpacing: '-.02em' }}>{activeCrit.nameAz}</div>
          <div style={{ fontSize: 11, color: '#6b7280', marginTop: 2 }}>Çəki: {(activeCrit.weight * 100).toFixed(0)}%</div>
        </div>

        {/* Progress */}
        <div style={{ padding: '.75rem 1.75rem', borderBottom: '1px solid #e5e7eb', background: '#f9fafb', display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ fontSize: 11, color: '#6b7280' }}>Ümumi tamamlanma:</div>
          <div style={{ flex: 1, height: 4, background: '#e5e7eb', borderRadius: 2, overflow: 'hidden' }}>
            <div style={{ height: '100%', background: '#1e63c8', borderRadius: 2, width: `${(completedCount / criteria.length) * 100}%`, transition: 'width .3s' }} />
          </div>
          <div style={{ fontSize: 11, fontWeight: 600, color: '#1a4fa0' }}>{completedCount}/{criteria.length}</div>
          <div style={{ fontSize: 10, color: saveMutation.isPending ? '#f59e0b' : '#10b981' }}>
            {saveMutation.isPending ? '⏳ Saxlanılır...' : '✓ Saxlanılıb'}
          </div>
        </div>

        {/* Questions */}
        <div style={{ padding: '1.75rem' }}>
          {activeCrit.questions.map(q => {
            // Şərti sual yoxlaması
            if (q.isConditional && q.conditionRule) {
              try {
                const rule = JSON.parse(q.conditionRule);
                const depAnswer = Object.values(answers).find(
                  a => activeCrit.questions.find(qx => qx.id === a.questionId && qx.code === rule.field)
                );
                if (!depAnswer) return null;
                if (rule.value && depAnswer.textValue !== rule.value) return null;
                if (rule.gt !== undefined && (depAnswer.numberValue ?? 0) <= rule.gt) return null;
              } catch { /* ignore */ }
            }

            return (
              <div key={q.id} style={{ marginBottom: '1.5rem' }}>
                {/* Sual başlığı */}
                <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start', marginBottom: '.6rem' }}>
                  <span style={{
                    fontFamily: 'JetBrains Mono, monospace', fontSize: 9, fontWeight: 600,
                    padding: '2px 7px', borderRadius: 4, flexShrink: 0, marginTop: 2,
                    background: q.isConditional ? '#cffafe' : '#deeafd',
                    color: q.isConditional ? '#0e7490' : '#1a4fa0',
                    border: `1px solid ${q.isConditional ? '#a5f3fc' : '#b8d4f8'}`
                  }}>{q.code}</span>
                  <div style={{ fontSize: 13, fontWeight: 500, color: '#0f1117', lineHeight: 1.5 }}>
                    {q.text}
                    {q.type === 'multiselect' && (
                      <span style={{ fontSize: 9, fontWeight: 700, color: '#1a4fa0', background: '#deeafd', border: '1px solid #b8d4f8', borderRadius: 4, padding: '1px 6px', marginLeft: 6 }}>MULTI-SELECT</span>
                    )}
                  </div>
                </div>

                {/* Cavab tipi */}
                {q.type === 'radio' && (
                  <div style={{ paddingLeft: 28 }}>
                    {q.options.map(opt => (
                      <div key={opt.id} onClick={() => setAnswer(q.id, { textValue: opt.value, optionId: opt.id })}
                        style={S.radioOpt(getVal(q.id)?.optionId === opt.id)}>
                        <div style={{
                          width: 15, height: 15, borderRadius: '50%', flexShrink: 0,
                          border: `2px solid ${getVal(q.id)?.optionId === opt.id ? '#1a4fa0' : '#d1d5db'}`,
                          background: getVal(q.id)?.optionId === opt.id ? '#1a4fa0' : 'transparent',
                          display: 'flex', alignItems: 'center', justifyContent: 'center'
                        }}>
                          {getVal(q.id)?.optionId === opt.id && (
                            <div style={{ width: 5, height: 5, borderRadius: '50%', background: '#fff' }} />
                          )}
                        </div>
                        {opt.text}
                      </div>
                    ))}
                  </div>
                )}

                {q.type === 'multiselect' && (
                  <div style={{ paddingLeft: 28, display: 'flex', flexWrap: 'wrap', gap: 7 }}>
                    {q.options.map(opt => {
                      const sel = getVal(q.id)?.selectedOptionIds?.includes(opt.id);
                      return (
                        <div key={opt.id} onClick={() => {
                          const current = getVal(q.id)?.selectedOptionIds || [];
                          const updated = sel ? current.filter(x => x !== opt.id) : [...current, opt.id];
                          setAnswer(q.id, { selectedOptionIds: updated });
                        }} style={{
                          padding: '7px 13px', border: `1.5px solid ${sel ? '#1a4fa0' : '#e5e7eb'}`,
                          borderRadius: 20, fontSize: 11, fontWeight: 500, cursor: 'pointer',
                          color: sel ? '#fff' : '#4b5563',
                          background: sel ? '#1a4fa0' : '#fff', transition: 'all .12s'
                        }}>
                          {opt.text}
                        </div>
                      );
                    })}
                  </div>
                )}

                {q.type === 'number' && (
                  <div style={{ paddingLeft: 28, display: 'flex', alignItems: 'center', gap: 10 }}>
                    <input type="number" min="0" style={S.numInput}
                      value={getVal(q.id)?.numberValue ?? ''}
                      onChange={e => setAnswer(q.id, { numberValue: parseFloat(e.target.value) || 0 })}
                    />
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div style={{ padding: '1rem 1.75rem', borderTop: '1px solid #e5e7eb', background: '#f9fafb', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ fontSize: 11, color: '#9ca3af' }}>Avtomatik saxlanılır</div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button onClick={() => setActiveCritIdx(Math.max(0, activeCritIdx - 1))}
              disabled={activeCritIdx === 0}
              style={{ padding: '7px 14px', border: '1px solid #e5e7eb', borderRadius: 8, background: 'transparent', color: '#4b5563', fontSize: 12, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit', opacity: activeCritIdx === 0 ? .4 : 1 }}>
              ← Əvvəlki
            </button>
            {activeCritIdx < criteria.length - 1 ? (
              <button onClick={() => setActiveCritIdx(activeCritIdx + 1)}
                style={{ padding: '7px 14px', background: '#1a4fa0', color: '#fff', border: 'none', borderRadius: 8, fontSize: 12, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit' }}>
                Növbəti →
              </button>
            ) : (
              <button onClick={() => {
                if (window.confirm('Assessmenti göndərirsiniz. Sonradan redaktə etmək mümkün olmayacaq. Davam edilsin?')) {
                  submitMutation.mutate();
                }
              }}
              disabled={submitMutation.isPending}
              style={{ padding: '7px 18px', background: '#047857', color: '#fff', border: 'none', borderRadius: 8, fontSize: 12, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit' }}>
                {submitMutation.isPending ? 'Göndərilir...' : '✓ Göndər'}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
