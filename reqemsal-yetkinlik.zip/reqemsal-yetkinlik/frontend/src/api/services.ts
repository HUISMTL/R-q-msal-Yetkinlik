// src/api/services.ts
import api from './client';

// ─── TYPES ───────────────────────────────────────────────
export interface User {
  id: string;
  username: string;
  fullName: string;
  role: 'SUPER_ADMIN' | 'ADMIN' | 'EKSPERT' | 'QIYMETLENDIRICI' | 'QURUM';
  organization?: { id: string; name: string; shortName?: string; group: string };
}

export interface Organization {
  id: string; name: string; shortName?: string; group: string; active: boolean;
}

export interface Assessment {
  id: string;
  organizationId: string;
  organization: Organization;
  year: number;
  status: 'DRAFT' | 'SUBMITTED' | 'IN_REVIEW' | 'APPROVED' | 'REJECTED';
  totalScore?: number;
  scores?: CriterionScore[];
  answers?: Answer[];
  submittedAt?: string;
  approvedAt?: string;
  createdBy?: { fullName: string };
  reviewedBy?: { fullName: string };
  reviewNote?: string;
}

export interface CriterionScore {
  id: string;
  criterionId: string;
  criterion: { code: string; name: string; nameAz: string; weight: number; orderIndex: number };
  systemScore?: number;
  adminScore?: number;
  justification?: string;
  isNA: boolean;
}

export interface Criterion {
  id: string; code: string; name: string; nameAz: string; weight: number; orderIndex: number;
  questions: Question[];
}

export interface Question {
  id: string; code: string; text: string; type: string; orderIndex: number;
  isConditional: boolean; conditionRule?: string;
  options: QuestionOption[];
}

export interface QuestionOption {
  id: string; text: string; value: string; orderIndex: number;
}

export interface Answer {
  questionId: string;
  textValue?: string;
  selectedOptionIds?: string[];
  numberValue?: number;
  optionId?: string;
  isNA?: boolean;
}

export interface AuditLog {
  id: string;
  action: string;
  details?: Record<string, unknown>;
  createdAt: string;
  ipAddress?: string;
  user?: { fullName: string; role: string };
  assessment?: { organization?: { name: string } };
}

// ─── AUTH ─────────────────────────────────────────────────
export const authApi = {
  login: (username: string, password: string) =>
    api.post<{ token: string; user: User }>('/auth/login', { username, password }),

  logout: () => api.post('/auth/logout'),

  me: () => api.get<User>('/auth/me')
};

// ─── USERS ───────────────────────────────────────────────
export const usersApi = {
  list: () => api.get<User[]>('/users'),

  create: (data: {
    username: string; password: string; fullName: string;
    role: string; organizationId?: string; email?: string;
  }) => api.post<User>('/users', data),

  update: (id: string, data: Partial<User> & { password?: string }) =>
    api.put<User>(`/users/${id}`, data),

  deactivate: (id: string) => api.delete(`/users/${id}`)
};

// ─── ORGANIZATIONS ────────────────────────────────────────
export const orgsApi = {
  list: () => api.get<Organization[]>('/organizations'),
  create: (data: { name: string; shortName?: string; group: string; website?: string }) =>
    api.post<Organization>('/organizations', data),
  update: (id: string, data: Partial<Organization>) =>
    api.put<Organization>(`/organizations/${id}`, data)
};

// ─── CRITERIA ────────────────────────────────────────────
export const criteriaApi = {
  list: () => api.get<Criterion[]>('/criteria')
};

// ─── ASSESSMENTS ──────────────────────────────────────────
export const assessmentsApi = {
  list: (params?: { status?: string; year?: number }) =>
    api.get<Assessment[]>('/assessments', { params }),

  get: (id: string) => api.get<Assessment>(`/assessments/${id}`),

  create: (data?: { organizationId?: string; year?: number }) =>
    api.post<Assessment>('/assessments', data || {}),

  saveAnswers: (id: string, answers: Answer[]) =>
    api.post<{ saved: number }>(`/assessments/${id}/answers`, { answers }),

  submit: (id: string) =>
    api.post<{ message: string }>(`/assessments/${id}/submit`),

  startReview: (id: string) =>
    api.post<Assessment>(`/assessments/${id}/review`),

  updateScores: (id: string, scores: { criterionId: string; adminScore: number; justification?: string }[]) =>
    api.put<{ updated: number }>(`/assessments/${id}/scores`, { scores }),

  approve: (id: string, reviewNote?: string) =>
    api.post<{ message: string }>(`/assessments/${id}/approve`, { reviewNote }),

  reject: (id: string, reviewNote: string) =>
    api.post<{ message: string }>(`/assessments/${id}/reject`, { reviewNote })
};

// ─── REPORTS ──────────────────────────────────────────────
export const reportsApi = {
  summary: (year?: number) =>
    api.get('/reports/summary', { params: { year } }),

  heatmap: (year?: number) =>
    api.get('/reports/heatmap', { params: { year } })
};

// ─── AUDIT ────────────────────────────────────────────────
export const auditApi = {
  list: (params?: { limit?: number; action?: string }) =>
    api.get<AuditLog[]>('/audit', { params })
};
