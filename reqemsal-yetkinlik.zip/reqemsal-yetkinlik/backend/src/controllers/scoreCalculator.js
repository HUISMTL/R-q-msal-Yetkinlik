// src/controllers/scoreCalculator.js
// Cavablardan D1–D12 üçün 0–5 bal hesablama məntiqi
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

/**
 * Bir assessment üçün bütün kriteriyaların balını hesabla
 * @param {string} assessmentId
 * @returns {Array} [{ criterionId, criterionCode, score }]
 */
async function calculateScores(assessmentId) {
  // Bütün cavabları çək
  const answers = await prisma.answer.findMany({
    where: { assessmentId },
    include: { question: { include: { criterion: true } } }
  });

  // Kriteriyaları çək
  const criteria = await prisma.criterion.findMany({ orderBy: { orderIndex: 'asc' } });

  const results = [];
  for (const criterion of criteria) {
    const critAnswers = answers.filter(a => a.question.criterionId === criterion.id);
    const score = scoreCriterion(criterion.code, critAnswers);
    results.push({ criterionId: criterion.id, criterionCode: criterion.code, score });
  }

  return results;
}

/**
 * Hər kriteriya üçün ayrıca bal hesablama funksiyası
 */
function scoreCriterion(code, answers) {
  const get = (questionCode) =>
    answers.find(a => a.question.code === questionCode);

  const val = (questionCode) =>
    get(questionCode)?.textValue || get(questionCode)?.option?.value || '';

  const num = (questionCode) =>
    get(questionCode)?.numberValue ?? 0;

  const selected = (questionCode) =>
    get(questionCode)?.selectedOptionIds || [];

  switch (code) {
    case 'D1': return scoreD1(val);
    case 'D2': return scoreD2(val);
    case 'D3': return scoreD3(val, selected);
    case 'D4': return scoreD4(val, num, selected);
    case 'D5': return scoreD5(val);
    case 'D6': return scoreD6(val);
    case 'D7': return scoreD7(val, selected);
    case 'D8': return scoreD8(val);
    case 'D9': return scoreD9(val, selected);
    case 'D10': return scoreD10(val, num, selected);
    case 'D11': return scoreD11(val);
    case 'D12': return scoreD12(val);
    default: return 0;
  }
}

// ─── D1: İdarəetmə (9%) ──────────────────────────────────
function scoreD1(val) {
  const s1 = val('S1');
  if (s1 === 'Xeyr') return 0;

  let score = s1 === 'Bəli, rəsmi vəzifəsi var' ? 2 : 1;

  const s2 = val('S2');
  if (s2 === 'Bəli, ayrıca şöbə') score += 1;
  else if (s2 === 'Tabeli rəqəmsal mərkəz var') score += 0.5;

  const s3 = val('S3');
  if (s3 === 'Bəli, CDTO/CIO') score += 0.5;

  const s4 = val('S4');
  if (s4 === 'Bəli, aktiv') score += 0.5;

  const s7 = val('S7');
  if (s7 === 'Bəli, hər ikisi') score += 0.5;

  return Math.min(5, Math.round(score * 10) / 10);
}

// ─── D2: Strategiya (10%) ────────────────────────────────
function scoreD2(val) {
  const s1 = val('S1');
  if (s1 === 'Xeyr') return 0;
  if (s1 === 'Hazırlanır') return 1;

  let score = s1 === 'Bəli, rəsmi təsdiqlənmiş' ? 2 : 1.5;

  if (val('S2') === 'Bəli, açıq paylaşılıb') score += 0.5;
  if (val('S3') === 'Bəli, konkret KPI-lər') score += 0.5;
  if (val('S4') === 'Bəli, müntəzəm') score += 0.5;
  if (val('S5') === 'Bəli, açıq paylaşılır') score += 0.5;
  if (val('S6') === 'Bəli, açıq istinad edilir') score += 0.25;
  if (val('S7') === 'Bəli, açıq dashboard') score += 0.25;

  return Math.min(5, Math.round(score * 10) / 10);
}

// ─── D3: Büdcə (7%) ─────────────────────────────────────
function scoreD3(val, selected) {
  const s1 = val('S1');
  if (s1 === 'Xeyr') return 0;

  const s2 = selected('S2'); // multiselect
  if (s2.length === 1 && s2.includes('Avadanlıq')) return 1;

  let score = s1 === 'Bəli, müntəzəm' ? 2 : 1.5;

  if (val('S3') === 'Bəli, ayrıca kateqoriya') score += 0.5;
  if (val('S4') === 'Bəli, dəqiq faiz bəllidir') score += 0.5;
  if (val('S6') === 'Bəli, ayrıca büdcə') score += 0.5;
  if (val('S7') === 'Bəli, sistemli') score += 0.5;

  return Math.min(5, Math.round(score * 10) / 10);
}

// ─── D4: İstifadəçi Yönümlü Xidmətlər (13%) ─────────────
function scoreD4(val, num, selected) {
  const s1 = val('S1');
  if (s1 !== 'Bəli') return 0;

  const onlineCount = num('S2b_online');
  if (onlineCount === 0) return 0.5; // Yalnız fiziki

  let score = 1;

  // DXR.az qeydiyyatı
  const dxr = val('S2a');
  if (dxr === 'Demək olar hamısı (85–100%)') score += 0.5;
  else if (dxr === 'Böyük hissəsi (60–85%)') score += 0.25;

  // Rəqəmsallaşma dərinliyi — end-to-end faizi
  const endToEnd = num('S3a_endtoend');
  if (endToEnd >= 75) score += 1;
  else if (endToEnd >= 50) score += 0.75;
  else if (endToEnd >= 25) score += 0.5;
  else score += 0.25;

  // MyGov inteqrasiyası
  const mygov = num('S4_mygov_web') + num('S4_mygov_mobile');
  if (mygov > 0) score += 0.5;

  // Proaktiv bildiriş
  const bildirish = selected('S6');
  if (bildirish.length >= 3) score += 0.5;
  else if (bildirish.length >= 1) score += 0.25;

  // API
  const s8 = val('S8');
  if (s8 === 'Bəli, açıq API-lər mövcuddur') score += 0.5;

  return Math.min(5, Math.round(score * 10) / 10);
}

// ─── D5: Məlumat Mədəniyyəti (8%) ───────────────────────
function scoreD5(val) {
  const s1 = val('S1');
  if (s1 === 'Xeyr') return 0;

  let score = s1 === 'Bəli, sistemli şəkildə' ? 1.5 : 1;

  const s2 = val('S2');
  if (s2 === 'Bəli, opendata.az-da aktivdir') score += 1;
  else if (s2 === 'Bəli, lakin köhnədir (1+ il)') score += 0.5;

  if (val('S3') === 'Maşınoxunan (CSV, JSON, XML)') score += 0.5;
  if (val('S4') === 'Bəli, tam formalaşdırılmış') score += 0.5;
  if (val('S5') === 'Bəli, hər üçü') score += 0.5;
  if (val('S6') === 'Bəli, açıq API') score += 0.5;

  const s7 = val('S7');
  if (s7 === 'Bəli, qərarlar data ilə əsaslandırılır və ictimaiyyətə açıqlanır') score += 0.5;

  return Math.min(5, Math.round(score * 10) / 10);
}

// ─── D6: G-Cloud (5%) ───────────────────────────────────
function scoreD6(val) {
  const s2 = val('S2');
  if (s2 === 'Heç biri') return 0;
  if (s2 === 'Hazırlanır') return 1;

  let score = 0;
  if (s2 === '100% — tam köçürülüb') score = 3;
  else if (s2 === '50–80% — böyük hissəsi') score = 2;
  else score = 1;

  if (val('S3') === 'Xeyr, tamamilə dayandırılıb') score += 0.5;
  if (val('S4') === 'Bəli, tam konfiqurasiya edilib') score += 0.5;

  const s6a = val('S6a');
  if (s6a === 'Bəli, tam') score += 0.5;

  const s6b = val('S6b');
  if (s6b === 'Bəli, hər ikisi') score += 0.5;

  return Math.min(5, Math.round(score * 10) / 10);
}

// ─── D7: EHİS (5%) ──────────────────────────────────────
function scoreD7(val, selected) {
  const s1 = selected('S1'); // multiselect
  if (!s1.length || s1.includes('Heç biri (açıq giriş)')) return 0;

  let score = 1;
  if (s1.includes('MyGovID')) score += 0.5;

  const s3 = val('S3');
  if (s3 === 'Bəli, tam EHİS/Digital Bridge üzərindən') score += 1.5;
  else if (s3 === 'Qismən Bridge, qismən birbaşa') score += 0.75;

  if (val('S4') === 'Bəli, tam avtomatik (sistem özü göndərir/alır)') score += 0.5;

  const s5 = val('S5');
  if (s5 === 'Hər ikisi' || s5 === 'Digital Finance platforması üzərindən') score += 0.25;

  if (val('S6') === 'Bəli, tam həyata keçirilib') score += 0.5;
  if (val('S7') === 'Bütün əsas məlumatlar EHİS-dən avtomatik gəlir') score += 0.25;

  return Math.min(5, Math.round(score * 10) / 10);
}

// ─── D8: İnfrastruktur (8%) ─────────────────────────────
function scoreD8(val) {
  const s2 = val('S2');
  let score = 0;

  if (s2 === 'Xeyr, HTTP ilə işləyir') return 0.5;
  if (s2 === 'Bəli, A+ səviyyəsi (SSL Labs)') score += 1.5;
  else if (s2 === 'Bəli, A səviyyəsi') score += 1;
  else score += 0.5;

  if (val('S1') === 'Bəli, daima işləkdir (≥99% uptime)') score += 0.5;

  if (val('S3') === 'Bəli, tam responsive dizayn') score += 0.5;

  if (val('S5b') === 'Bəli, standartlara uyğun') score += 0.25;

  const s6a = val('S6a');
  if (s6a === 'Bəli, test edilib') score += 0.5;
  else if (s6a === 'Bəli, lakin test edilməyib') score += 0.25;

  if (val('S6b') === 'Bəli, hər ikisi') score += 0.25;

  if (val('S7a') === 'Bəli, avtomatik xəbərdarlıq sistemi ilə') score += 0.5;
  if (val('S7b') === 'Bəli, açıq xidmət status səhifəsi var') score += 0.25;

  return Math.min(5, Math.round(score * 10) / 10);
}

// ─── D9: Süni İntellekt (9%) ─────────────────────────────
function scoreD9(val, selected) {
  const s1 = val('S1');
  if (s1 === 'Xeyr') return 0;
  if (s1 === 'Xeyr, planlaşdırılır') return 1;

  let score = s1 === 'Bəli, istismar rejimindədir' ? 2 : 1.5;

  const s2 = selected('S2');
  if (s2.length >= 4) score += 0.5;
  else if (s2.length >= 2) score += 0.25;

  const s3 = val('S3');
  if (s3 === '4 və daha çox') score += 0.5;
  else if (s3 === '2–3 tətbiq') score += 0.25;

  if (val('S4') === 'Bəli, ayrıca komanda') score += 0.5;

  const s5 = val('S5');
  if (s5 === 'Hər ikisi var') score += 0.5;
  else if (s5 === 'Yalnız strategiya' || s5 === 'Yalnız əməkdaşlıq') score += 0.25;

  if (val('S6') === 'Bəli, hər ikisi') score += 0.5;

  return Math.min(5, Math.round(score * 10) / 10);
}

// ─── D10: Rəqəmsal Komanda (9%) ──────────────────────────
function scoreD10(val, num, selected) {
  const s1 = val('S1');
  if (s1 === 'Xeyr, kənar şirkətə verilir') return 0.5;

  let score = 1;
  if (s1 === 'Bəli, ayrıca şöbə var') score = 2;
  else if (s1 === 'Tabeli rəqəmsal mərkəz var') score = 1.5;

  const s3 = val('S3');
  if (s3 === 'Bəli, CDTO/CIO səviyyəsi') score += 0.5;
  else if (s3 === 'Bəli, İT müdiri/direktoru') score += 0.25;

  const s4 = selected('S4'); // multiselect ixtisaslar
  if (s4.length >= 6) score += 0.75;
  else if (s4.length >= 4) score += 0.5;
  else if (s4.length >= 2) score += 0.25;

  if (val('S5') === 'Bəli, bir neçə nəfər') score += 0.5;
  if (val('S6a') === 'Bəli') score += 0.25;
  if (val('S6b') === 'Bəli, rəsmi plan var') score += 0.25;

  return Math.min(5, Math.round(score * 10) / 10);
}

// ─── D11: Daxili Proseslər (9%) ──────────────────────────
function scoreD11(val) {
  const s1 = val('S1');
  if (s1 === 'Əsasən kağız əsaslıdır') return 0;

  let score = 0;
  if (s1 === 'Tam rəqəmsal mühitdə — ERP sistemi ilə') score = 2;
  else if (s1 === 'Qismən rəqəmsal — bir hissəsi rəqəmsal, bir hissəsi kağız') score = 1.5;
  else score = 1; // Yalnız ESD

  const s2 = val('S2');
  if (s2 === 'Bəli, hər ikisi (SIMA və Asan İmza)') score += 0.5;
  else if (s2 !== 'Tətbiq olunmur') score += 0.25;

  const s3 = val('S3');
  if (s3 === '80–100%') score += 0.5;
  else if (s3 === '60–80%') score += 0.25;

  if (val('S4') === 'Bəli, real vaxt dashboard var') score += 0.25;
  if (val('S5') === 'Bəli, tam inteqrasiya edilib') score += 0.5;

  if (val('S7a') === 'Bəli, tam tətbiq olunub') score += 0.5;
  if (val('S7b') === 'Bəli, tam') score += 0.25;

  return Math.min(5, Math.round(score * 10) / 10);
}

// ─── D12: Təhlükəsizlik (8%) ─────────────────────────────
function scoreD12(val) {
  const s1 = val('S1');
  if (s1 === 'Xeyr, ayrıca bölmə yoxdur') return 0.5;

  let score = s1 === 'Bəli, ayrıca şöbə/idarə' ? 1.5 : 1;

  if (val('S2') === 'Bəli, rəsmi vəzifəsi var (CISO)') score += 0.5;
  else if (val('S2') === 'Bəli, faktiki məsul şəxs var') score += 0.25;

  if (val('S3') === 'Bəli, açıq dərc edilib') score += 0.25;
  else if (val('S3') === 'Bəli, daxili sənəd') score += 0.1;

  const s4a = val('S4a');
  if (s4a === 'Bəli, göndərilib və nəticə alınıb') score += 0.5;
  else if (s4a === 'Bəli, göndərilib, gözlənilir') score += 0.25;

  if (val('S4b') === 'Bəli, test edilib') score += 0.25;

  if (val('S5') === 'Bəli, sertifikat var') score += 0.5;

  if (val('S6a') === 'Bəli, 24/7 aktiv SOC') score += 0.5;
  else if (val('S6a') === 'Bəli, iş saatları ərzində') score += 0.25;

  if (val('S6b') === 'Bəli, ildə 1+ dəfə') score += 0.25;

  if (val('S7a') === 'Bəli, tam tətbiq olunub') score += 0.5;
  if (val('S7b') === 'Bəli, tam avtomatik xəbərdarlıq sistemi ilə') score += 0.25;

  return Math.min(5, Math.round(score * 10) / 10);
}

module.exports = { calculateScores };
